# Riftline 3.61.0 — Grafikupdate und neue Testbasis

Vorbereitet für Anton037/Riftline. GitHub wurde nicht verändert: Die verbundene App verweigert Schreibzugriff.
Lokaler Stand: 2d505ea6308752311a7a8829ec7bc663d57b4c94 auf codex/biome-quality-overhaul.
Basis: d97857e9270dc88835740750b7d20ea7fe35c091. Der kumulative Patch enthält Grafikupdate UND Test-Neuaufbau.

## Inhalt

- `source/`: vollständiger aktueller Quellcode, einschließlich neuer Tests und Workflows.
- `web/`: fertig gebautes Spiel für einen HTTP-Webserver.
- `Riftline-3.61.0.patch`: kumulativer Git-Diff, einschließlich entfernter Dateien.
- `source/docs/VISUAL-REVIEW-3.61.md`: Grafik-Kriterien, Biom-Bewertung und Zeichenaufrufe.
- `source/docs/TESTING.md`: neue Testbasis, Zeitlimits und bewusst reduzierte Abdeckung.
- `verification/`: erfolgreiche Prüfprotokolle der neuen Testbasis.

## Patch anwenden

In einem sauberen Checkout der angegebenen Basis:

```sh
git switch -c update/visuals-and-tests
git apply --check /pfad/zu/Riftline-3.61.0.patch
git apply /pfad/zu/Riftline-3.61.0.patch
npm ci
npx playwright install --with-deps chromium
npm run check
git add -A
git commit -m "Improve biome visuals and rebuild the test foundation"
```

Danach den Branch per Pull Request einreichen. Der Patch löscht auch die alten Tests; bloßes Kopieren
von `source/` über einen bestehenden Checkout würde diese Dateien nicht entfernen.
Aus `source/` starten: `npm ci`, `npm run build`, `npm run serve`.
`web/` braucht HTTP, z. B. `python3 -m http.server 8124` im Ordner.

## Aktuelle Ergebnisse

- Neue Basis: 10 Node-Tests und 2 Browser-Abläufe, alle bestanden, einschließlich Build 27,9 s.
- Separater E2E-Lauf: Desktop und Touch bestanden in 27,1 s.
- Dieselben Abläufe mit echten Grafik-Ausgaben: bestanden in 55,4 s.
- Formatierung und ESLint bestanden; drei Workflow-Dateien als YAML geprüft.
- Separater Audio-Budget-Vergleich: alle sechs Biome stimmen mit dem realen Audioknoten-Weg überein.

Standard-Browser-Tests unterdrücken GPU-Zeichenaufrufe; Simulation, UI und Eingaben laufen echt.
`npm run test:render` aktiviert die Grafik-Ausgabe. Standard: 25 s je Ablauf und 75 s Gesamtlimit
für den Testprozess, zusätzlicher Build-Abbruch nach 30 s. Schwere Audio-/Grafikprüfungen sind manuell.

Die alten Golden-/Welt-/QA-/Soak-/Fuzz-Ketten und das ausgelieferte Selftest-Bundle sind entfernt.
Damit ist die Abdeckung bewusst kleiner. Offline-Wiederherstellung, Langzeitläufe, breite Geräte- und
Menüprüfungen sowie Spielgefühl brauchen gezielte Abnahme. Frühere Prüfungen des Grafikupdates sind
historische Evidenz, keine Bestandteile der neuen Suite. Keine FPS- oder echte Handy-Test-Freigabe.
GitHub Actions konnte mangels Schreibzugriff noch nicht auf GitHub laufen.

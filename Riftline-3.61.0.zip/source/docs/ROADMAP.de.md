# Riftline – Wünsche des Eigentümers und Plan

As of 27.10.2026, with 3.57.0. New entries are written in English (the owner's wish since 03.10.2026).

## 03.11.2026 — fresh test foundation (supersedes the policy below)

Following the owner's request to remove and rebuild the tests, the historical browser chains,
per-release self-test and golden catalogs are removed. The replacement uses Node's built-in runner:
ten unit contracts and two desktop/touch flows. Default flows run live simulation and UI with GPU draws
suppressed; real pixel rendering and visual/audio review are explicit commands. PRs and deployments
use one bounded gate, without change planners or hidden extended suites. This deliberately reduces
coverage; offline recovery, long sessions and device-specific comfort still need manual acceptance.

## 03.11.2026 — tests matched to risk (same 3.61.0 update)

The owner explicitly asked to simplify all tests, especially the slow deep test, and remove unnecessary work.
`docs/TESTING.md` replaces the previous always-run-everything policy. The normal gate retains save/simulation,
data/package and real-player smoke coverage. CI selects audio, gameplay, offline and full-biome checks from changes.
The audio test drops subjective FFT/style rankings, separates the historical self-test, and closes a fresh browser
per small sound chunk/place. Pure music budgeting no longer allocates unrendered native sources; real-node parity
is checked for all six places. Two overlapping screenshot scripts and the duplicate release-check chain are removed.
Full UI/E2E, old regressions, art review, soak/fuzz and sound analysis remain explicit tools rather than mandatory
work on every small update. Removed-setting assertions are updated to the current UI rather than restoring controls.

## 03.11.2026 — visual consistency and full-biome review (3.61.0)

The current request is a whole-game review with consistent criteria, led by the unequal biome graphics.
`docs/VISUAL-REVIEW-3.61.md` records the rubric, findings, measured render costs and validation limits.

- Phase 2 is implemented: all six weather profiles and prop emission rates are named data in
  `src/data/atmosphere.js`. Base emission rates stay the same; particle sizes vary within a small range.
  Atmosphere now yields under particle pressure and stops adding particles above 30% pool occupancy.
  This intentionally replaces the earlier “match counts within 10%” gate with a combat-reservation gate.
- Readability/material pass across all six floors: broken, snow-buried ice fractures; worn Core tiles with
  sparse lit seams and quieter decorative runes; lower marsh vein contrast; finer wet asphalt and glass
  grain; calmer molten bounce and narrower glass joints. Hazard timing and warning geometry stay intact.
- Phases 4/5 are partially addressed by batching compatible opaque static siblings by material. Animated
  objects, instanced vegetation and translucent surfaces keep their own identity and sorting. Transparent
  bosses are deliberately excluded, so the earlier universal 7–10-mesh target is not claimed as achieved.
- The landscape phone boss bar moves between the sticks so it no longer crosses the boss or the wave/combo stack.
- `npm run audit:visual` captures all six biomes and bosses with a fixed run seed on PC and landscape touch.
  The existing biome/attack screenshot suites also visit every biome; the Flats now has its own attack stage.
- No engine migration or new progression mechanics are needed for these findings. A real-device gameplay,
  audio listening and GPU timing pass remains necessary before calling the whole game release-ready.

## 28.10.2026 — biomes, enemies and effects: the overhaul, scoped (after 3.59.0)

The owner asked for a biome, enemy and effect overhaul. This is the plan, grounded in what is actually
asymmetric today, in the order it should be done. Each phase has a gate; nothing here is "make it prettier".

**What is measured, not guessed**

- **Ambient particles are per-place hand code.** `rlAmbient` in `src/render/biome-visuals.js` is a `switch` on
  `biome.id` with the numbers written inline: the vault emits 34 flakes/s (was 42, cut in 3.44.0), the marsh
  9 spores plus 4 fireflies plus the reed wind, the club 22 ash plus 11 embers (raised in 3.54.0). Every one of
  those was tuned by eye, one release at a time, and nothing in the file states the intent — so the next change
  is another guess. That is the real defect: not the densities, the fact that they are incomparable.
- **Enemies arrive identically.** All 25 types have their own silhouette, animation, family death voice
  (`RL_DEATH_FAMILY`, 25/25 mapped) and a kill burst tinted by `enemyDefs[type].color` — but `spawn` drew one
  ring and one burst of one size for every type (`renderer.js`, `case "spawn"`): the colour was the type's own,
  the shape was the same for all 25. Phase 1 fixes that; the rest of the phase is the family flourish.
- **Bosses are 20–33 meshes each** (AUDIT.md M7), the largest single draw-call cluster left after 3.59.0.

**Phase 1 (S) — a spawn that says what arrived.** Tint the spawn ring by the enemy's own colour and give the
family a shape: fast types land with a streak, armoured ones with a heavy ring, flyers with a small vertical
puff. Reuses `emit`/`ring` only, so no new per-frame draw calls. Gate: `npm run screens` per place, and a
`selftest` assertion that every type in `enemyOrder` has an arrival shape.

**Phase 2 (M) — the ambient table.** Move the per-place numbers out of the `switch` into a data table
(rate, colour, vertical drift, size, drag per place) so a reader can compare two places at a glance and a
reviewer can see a density change in the diff. Gate: the 3.58.0 screenshots matched within 10 % particle
count per place.

**Phase 3 (M) — wind-ups.** The field guide promises "chargers telegraph, then ram"; check every damaging
attack for a wind-up of at least 0.25 s with a family sound, and give the ones without one a tell. Gate:
`selftest` walks the enemy table and asserts each damaging attack has a wind-up field.

**Phase 4 (L) — boss meshes.** Merge non-spinning parts per material (AUDIT.md M7: 20–33 → 7–10 draw calls).
Gate: `npm run screens`, one image per boss per phase.

**Phase 5 (L) — the prop merge left in AUDIT.md H3.** Same treatment for the marsh and the club, which still
carry the most per-prop meshes.

**Tooling, done here (3.60.0, no gameplay change):** `tests/balance.mjs` now draws its seeds from a fixed list
and prints every seed's death wave, marking a row `noisy` when the spread reaches four waves. Before this, a
run's rng was consumed by the spawn plan, so 3.58.0's one-enemy escort cut reseeded everything after wave 5 and
moved the Rocket from wave 9 to wave 5 with no balance change behind it. A median of four chaotic runs was
being read as a ranking; the spread says which rows can be read at all.

## 27.10.2026 — project process back on `main` (3.57.0)

`main` had lost its own process documents: they only existed on unrelated, re-rooted `claude/*` branches. They
are restored here from those branches and reconciled with the code that is actually on `main`:

- `CLAUDE.md`, `docs/DEVELOPMENT.md`, `docs/GITHUB.md`, `docs/STRATEGY-AUDIT.md` and this roadmap are back.
  The release instructions in `CLAUDE.md`/`DEVELOPMENT.md` were corrected: the version and the build id move
  together, and since 3.57.0 `src/build-info.json` is only a start-up identity, not a changelog (the build
  writes just its version and build id to `dist/`).
- `.github/workflows/nightly.yml` is recreated (it was referenced by `test.yml` but missing): the long checks
  (E2E, short fuzz, world/run audits, screenshots as an artifact) plus the soak and the balance table.
- The stale German `docs/QA-REPORT.de.txt` was deliberately **not** restored: it stops at 3.29.1 and would
  contradict 27 releases of `main` (removed Ultra, five biomes, old boss names). The What's new tab
  (`src/data/whatsnew.js`) is the player-facing history instead.

The strategy section below is unchanged and still the owner's direction; the ranked improvements in
`docs/STRATEGY-AUDIT.md` stay the plan.

Diese Datei sammelt, was der Eigentümer sich gewünscht hat, was entschieden ist und
welche Ideen noch offen sind. Zu Beginn einer Sitzung lesen, nach jeder Änderung des Plans aktualisieren (im selben PR).

Leitgedanke des Eigentümers (steht auch in `CLAUDE.md`): alle Funktionen, Designs und Sounds passen organisch und
dynamisch zusammen; das Spiel skaliert und wird schwerer, und sieht und klingt dabei schön. Neue Funktionen kommen
mit Modell, Sound, Vorwarnung und Tests, nicht als nackte Mechanik. Der Eigentümer prüft Klang und Spielgefühl selbst:
Musik und Balance sind von uns nur gemessen, nicht gehört oder gespielt.

## Strategy audit of 10.10.2026 (on 3.29.1; read this first)

**State.** Live: 3.29.1 (#58). The "CURRENT STATE" of 06.10.2026 below is older; 3.29.0 and 3.29.1 have been merged since.

**The request.** The owner asked how to make Riftline a substantially better finished game: its look, sound, feel and
performance, while friends can still open one link and play on ordinary phones, tablets and PCs. He asked for an
investigation, decisions and a plan, not for changes. The full report, with the raw measurements and how to repeat them, is
in `docs/STRATEGY-AUDIT.md`.

**How it was judged.**

- Screenshots and `renderer.info` of every biome (wave and boss) on PC and on a phone held sideways, taken from the live site
  in software WebGL.
- Offline renders of all 15 music tracks and 17 sound effects, measured for loudness, spectrum and stereo.
- Simulation and audio cost measured in a crowded fight; the source code read.
- **Not done:** no listening, no real devices, no play-testing.

**Recommended direction.** Stay on three.js and the web, and change how the content is made:

- **Made in Blender** (or licensed CC0) and imported as glTF: arena surroundings, landmarks and floors with **baked
  lighting**. The arena is static and the camera nearly fixed, so baked light gives the better look at almost no runtime
  cost (unlike Ultra).
- **Kept in code:** simulation, combat effects, telegraphs, hazards' animation and the adaptive music.
- **Not recommended:** Godot. Its web export runs only the reduced "Compatibility" renderer, its low-latency browser audio has
  no effects, reverb or generated sound, the download is large, and it would mean a full rewrite. Babylon.js, WebGPU, an
  engine switch or a backend bring no gain now.

**Main findings.**

1. **No sense of place.** Each arena is a flat patterned floor from above with box obstacles and nothing around the edge;
   Blackout City does not read as a city.
2. **Readability.** The biome skins paint the floor's pattern on enemies (`render/biome-visuals.js` `rlSkinMaterial`), so in
   Ember Works and the Toxin Marsh enemies and bosses (Crucible, Hive Queen) blend into the floor. At their intro the bosses are
   small, at the top edge, under the boss bar. The floors are busy, high-contrast graphics and fill about 70 % of the picture.
3. **Sound (measured, not heard).**
   - Music: 71–92 % of the energy is below 200 Hz, almost nothing above 8 kHz.
   - Explosion, nova, rocket and scattergun: 86–96 % below 200 Hz.
   - The mix is near mono, and the biomes have very similar tonal balance.
   - Phone speakers barely play that range, so music and impacts mask each other in it. This is likely part of "the biomes
     sound the same" and of the missing Osmos shimmer.
4. **No frame cap on Auto and High** (`main.js`, `qualityPresets` `fps: 0`). 90/120 Hz Android phones render up to 120 fps,
   about twice the GPU work and heat. Auto quality only steps down below 48 fps. The likely main GPU cost is the full-screen
   procedural floor shader at DPR 1.5–2. All inferred from source, not measured on a device.
5. **Light elsewhere (measured).** 405 KB download, 68–127 draw calls, 12k–47k triangles, 18–21 MB heap, 0.44 ms per
   simulation step with 56 enemies.

**First batch of work** (each a small PR):

1. 60 fps cap by default on phones and tablets, Auto quality working to a pixel budget, and a `?perf` readout built on the run
   monitor in `core/diagnostics.js`.
2. A device baseline: the owner and 2–3 friends run `?perf` on their phones (a low-end and a 120 Hz Android, an older and a
   current iPhone, an iPad, a laptop).
3. A readability pass: skins as an accent only, calmer floors, bigger bosses that spawn away from the HUD bar, tips off the
   play area on phones.

**After that:** 4. Audio mix pass, procedural only: the bass reserved for impacts and the boss kick, one bright signature voice per biome,
transient layers on impacts, wide but mono-safe beds, loudness targets in tests. The owner listens on a phone speaker and on
headphones. 5. glTF asset pipeline (lazy load per biome, service-worker cache, size check in `build.js`). 6. **Blackout City pilot**: Blender kit, baked light, border and backdrop. Go or no-go judged on phones. 7. Recorded impact and ambience layers (1.5 MB at most, AAC or MP3). 8. A fullscreen button for Android and desktop, an iOS "Add to Home Screen" hint, a visible save export and import. 9. The rest of the biomes, one per PR; later perhaps authored boss models.

**Decisions for the owner:**

- The frame-cap default (also on desktop?).
- Approve an art direction and send a reference picture.
- iPhone silent switch: `audioSession.type = "ambient"` lets the switch mute the game; `playback` would ignore it.
- A licence policy for assets.
- Cloudflare Pages only as a preview link per pull request, to try changes on a phone before merging; GitHub Pages stays the
  public link, and the leaderboard plan stays parked.
- Which devices must run well.

**Still unverified:** real heat and frame rate on phones; whether the mix sounds as bad as it measures; iPhone behaviour
(silent switch, a phone call during a run, separate storage of home-screen apps); the feel of play.

## Entschieden am 03.10.2026 (nach 3.5.0)

Reihenfolge vom Eigentümer bestätigt: erst die schnellen Sachen und Fixes, dann die größeren Dinge. Jeder Punkt ein
eigener PR mit Release.

1. **3.6.0 Steuerung anpassbar + Checkup-Fixes** (erledigt): Editor „Button layout“ in den Einstellungen (DASH, NOVA,
   GADGET und Pause frei verschieben und skalieren, Deckkraft, Stickgröße, fester Bewegungs-Stick; Hoch- und
   Querformat getrennt; Linkshänder spiegelt), Dash-Untergrenze, Orbital Blades, Combo Surge, Säurepfützen,
   Upgrade-Bildschirm, Saver-Modus (siehe QA-Bericht 3.6.0).
2. **3.7.0 Musik neu** (erledigt, wartet auf das Ohr des Eigentümers; MP3-Vorschau aller zehn Tracks geschickt): Das
   laute Rauschen gefällt dem Eigentümer nicht. Messung (3.5.0): die
   Atmosphären der ruhigen Themen sind eine 1 s lange Schleife aus weißem Rauschen; oberhalb von 200 Hz (das, was ein
   Handy-Lautsprecher spielt) ist das im Cryo Vault etwa 75 % des Klangs, in der Toxin Marsh etwa 50 %, in Blackout
   City etwa 35 %. Plan: kein Dauerrauschen mehr, sondern einzelne, gepannte Geräusche des Ortes (Tropfen,
   Eisknacken, Grillen als Töne, Glut-Knistern; das ist zugleich das „Ambient je Biom“ aus Punkt 2 unten), wo Rauschen
   bleibt rosa/braun, länger und leiser; die Biom-Events ebenso; ein Test für den Rauschanteil.
   **Boss-Tracks in neuem Stil, entschieden: Cinematic Synth** („wir probieren es erst mal so“): Taikos und große
   Trommeln, kurze Streicher-Figuren, Blechbläser-Stöße, Chor, Arpeggios, Sub-Bass mit Pumpen, keine verzerrten
   Gitarren und keine Rausch-Becken; das Motiv jedes Bioms bleibt die Leitmelodie. Warden: Cyberpunk-Verfolgung,
   Crucible: Schmiede-Taikos und Blech, Frost Prism: Eis-Trance, Hive Queen: Tribal und Acid-Bass, Rift Core: Drum &
   Bass mit Chor als Finale. Boss-Phasen mit eigenem Abschnitt, weicher Übergang ruhig → Boss. WAV/MP3-Vorschau aller
   Tracks an den Eigentümer vor dem Merge.
3. **Boss-Belohnungen** (Punkt 1 unten; after the checkup of 03.10.2026 probably 3.10.0).
4. **Läufer statt Drohne** mit Schritt-Sounds (Punkt 2 unten).
5. Cloudflare erst, wenn der Eigentümer Bescheid sagt.

## Requested on 03.10.2026 (after 3.7.0): checkup, prettier hazards, biomes that sound different

From this request on, everything is written in English (the owner's wish; earlier entries stay as they are).

The owner's request: look through the whole project again carefully, find things he may not like that much and look
for bugs; then a plan, fixes first, then features, in logical PRs one after another. His examples: "the music is good
but all biomes sound pretty much the same, maybe add more effect sounds to each one" and "the fire pillars, ice areas,
manholes etc. are all just colored circles, maybe make them prettier".

What the review found: `npm test` and `npm run audit` green (bot run to wave 22 without runtime errors). The map hazards
(lava vents, manholes, ice sheets, acid pools, portals) really are only discs and rings of the effect pools
(`drawFeatures` in `render/renderer.js`), the lava eruption a glowing tube; the traps have had real models since 3.0.0.
The biomes differ in sound almost only by their music: since 3.7.0 the sounds of a place are soft notes of the calm
themes, and the hazards are silent until a vent erupts.

Order (one PR with a release each, to be merged one after another):

1. **3.7.1 Fixes** (done): Endless with Cryo Skates locked the dash for minutes (the clock was reset, the time of the
   last dash was not); with a high hazard resistance acid ticks below one point counted as hits (sound, shake, red
   flash, Heat Sink), now the fraction is kept; a dodged trap strike (dash, shield) still slowed; electric traps
   (plate, rift burst) showed the ice sparkle and played the frost ping, now they stun with their own effect and sound
   (see the QA report of 3.7.1).
2. **3.8.0 Hazards with real models** (done, `render/hazards-view.js`): lava vents as basalt craters with moving lava
   and a pillar of fire instead of a tube, manholes with an iron cover in a concrete collar (the cover rattles and
   lifts, jagged bolts), ice sheets with frost, cracks and ice shards on the rim, acid with a bubbling surface and a mud
   bank, portals with a swirl and floating rune stones. The warnings keep the language of the rings. The owner also
   asked to remove the "Left-handed" and "Reduce flashes" settings completely; done in the same release.
3. **3.9.0 Sounds of the place** (done, `audio/place.js`): the hazards sound by distance and direction (lava bubbles and
   rumbles before it erupts, manholes hum and crackle, ice cracks under the drone, acid bubbles, portals hum), rare far
   sounds of each biome (thunder and a car alarm, anvils and steam, ice cracking, frogs and birds, deep swells in the
   Void) and a volume of their own, "Ambience" (item B7 of the proposals below).
4. Then as planned: boss rewards (then 3.10.0; after the request of 04.10.2026 3.13.0), the walker.

## Requested on 04.10.2026 (after 3.9.0): what the polish missed, music and ambience of the place

The owner's request: look through the project again for things that "missed" the polishing of the last days (biome
details and enemy skins are there, but some effects are still simple, like the pools that were just coloured circles),
make the music fit the atmosphere of each place, and add more sounds of the place in reasonable amounts (Blackout City:
more thunder, light rain, a few sirens; Ember Works: anvils and machinery; the same for every biome), with the volumes
right.

What the review found (screenshots of every attack in every biome): the zones of the attacks of enemies and bosses
(`world.hazards`: the Warden's stomp, the Crucible's hammer, slag rings and eruptions, the Frost Prism's nova and
glaciers, the Hive Queen's plague, the Rift Core's bombardments, mortar shells, minebot mines, sapper charges, burning
and volatile ground) were all the same red ring around a flat red disc with one generic blast and one `boom` sound;
every blast and kill left the same black blob in every biome; every enemy shot was a glowing ball. The calm themes share
one template (motif rhythm, heartbeat, sub); the place is only in the instrument and rare notes. The sounds of the place
(3.9.0) are one far sound every 5 to 11 s from four or five per biome, nothing tied to the props; no test measures
ambience against music and effects.

Decisions of the owner (04.10.2026):

- Order as proposed, each its own PR with a release: visuals first, then the soundscapes, then the music.
- Calm themes: keep melody and key, rebuild rhythm and instruments per place (option a).
- Rain in Blackout City: yes, but no constant "white noise" kind of rain (soft patter and single drops).
- Visual tie-ins where they are logical (a lightning flash in the sky with the thunder, a faint red and blue glow of a
  passing siren on the skyline).

Plan:

1. **3.10.0 Attacks with a look and sound of their own** (done, `render/attacks-view.js`): surfaces per attack (cracks,
   lava cracks, molten pools, frost from the rim, acid, rifts, turning targets with a countdown, smouldering ground);
   mines, charges and mortar shells with models; blasts of their kind (ice spikes, pillars of fire, bolts of light,
   splashes) with sounds of their own; marks of the place instead of the black blob; enemy shots with shapes of their
   kind. The warning ring stays.
2. **3.11.0 Soundscapes** (done as 3.13.0, see the HANDOFF): per biome a soft steady layer, sounds from the props near the drone and far sounds in
   variants, with rate limits per sound (for example thunder about every 25 to 50 s, a siren about every 60 to 120 s),
   never two big sounds at once, no repeats, thinner in boss fights. Blackout City: light rain (patter, gutter drips,
   rain on metal), thunder with lightning, sirens with their light, a helicopter, a horn, a dog, a buzzing street lamp.
   Ember Works: anvil series, a drop hammer, conveyors and gears near the conveyors, steam valves and a steam whistle,
   chain hoists, a molten pour, the roar of the furnaces. Cryo Vault: howling gusts, glacier groans, icicles, a far
   avalanche, crystals that ring. Toxin Marsh: frog choruses, crickets and cicadas, insects flying past, splashes, an
   owl, a heron. Void Core: the heartbeat of the core, a gravity hum near the rune stones, reversed sounds, metallic
   resonances, chirps. Levels measured from offline renders (ambience well below the music, no far sound louder than a
   shot, hiss under the 3.7.0 limit) and locked in tests; MP3 previews of every biome before the merge.
3. **3.12.0 Music of the place**: keys and motifs stay, rhythm and instruments come from the place (Ember Works an
   industrial beat of hammers, pistons and conveyors; Blackout City noir with an electric piano, a walking bass,
   brushes, rain plinks and a siren on a chord tone; Cryo Vault refined; Toxin Marsh bayou with kalimba, log drum,
   frog croaks in time and a wobbling drone; Void Core glass, choir, reversed swells, glitches); the boss tracks take
   the place sounds into their drums; the ambience thins out where the music already carries a sound; MP3 previews of
   all ten tracks before the merge.
4. Then the boss rewards (done in 3.15.0, see the HANDOFF), the walker. (Renumbered on 04.10.2026: the owner's later requests come first, as 3.11.0
   landscape only and 3.12.0 the Singularity, so the soundscapes become 3.13.0 and the music 3.14.0.)

### HANDOFF (05.10.2026, after 3.15.0; history)

**State.** 3.10.0 to 3.14.0 and the repository cleanup were merged on the morning of 05.10.2026 and are live. The
owner merges stacked PRs one after another (base of each switched to main before merging; a merged branch is only
deleted once the next PR targets main, or GitHub closes the next one, as happened to #31). 3.15.0 (boss rewards) is its
own PR against main.

**3.15.0 boss rewards, decisions of the owner (05.10.2026):** a chance of 30 % for the boss's card that grows by 15 %
after each boss offer without one; the Rift Core's card is Event Collapse (the Nova pulls first, then blasts harder;
"Singularität" clashed with the gadget); each card at most once per run, also in Endless. Built in
`core/boss-cards.js` (mechanics and chance) and `render/boss-cards-view.js` (looks); the boss offer keeps its rare,
epic and legendary cards (as before). Only tested in software: whether the five cards feel strong enough for a boss
reward (the numbers are in the constants at the top of `core/boss-cards.js`).

**Open, for the owner:** try the Singularity, the soundscapes and the music of the place in the game (the owner
prefers that to the MP3 previews); whether tablets stay landscape-only too; the GitHub settings of the repository
(description, website, topics, social preview, a license).

**Check of 05.10.2026 (the owner: "check the project again… at least the Warden boss still had the same old
attacks").** Every promise of the requests since 03.10.2026 was checked against the code. Done in 3.16.0: the Warden,
Hive Queen and Rift Core fired the generic orb (now siren slugs, spores, rift rings), the Warden's laser grid and the
Rift Core's beams were the generic beam (now the security laser and the rift ribbon), the boss volleys shared one sound
and many were silent (now a voice per boss on every volley), the Warden's charge hit the wall without a mark (now it
cracks), the weaver's volley was silent and the carrier played the gunner's sound, Searing Collapse had no burning
ground. Also done in 3.16.0 (the owner: integrate it now, not later): the sounds of the props near the drone (street
lamps of Blackout City, gears on the machines of the Ember Works, obelisks of the Void Core), the Cryo Vault theme with
the rhythm of its place, the boss tracks of the Frost Prism, Hive Queen and Rift Core with their place in the drums, the
portals a boss calls open in its colours, the sentinel's beam in the skin of its place, and a test that the ambience
stays below the music. Not done, because not asked for: the Hive Queen's eggs and summons still hatch with the shared
burst.

**3.17.0 the walker (done, 05.10.2026):** two legs (the owner's decision: two, not four), the weapon on its back; legs
follow the stride of the world (`core/walk.js`), a dash is a jump with a landing, a footstep per ground with a servo
whine, dust of the ground at every foot. Not built: sliding on ice has no sound of its own (the ice footstep is the
scrape), no steps near lava or manholes (the place sounds cover them), and the texts still say "drone" (the owner's
word for the player's unit). Only seen in software and measured: how the legs look while moving fast (6 steps a second
at full speed) and whether the footsteps feel too busy in a long run, the level is a constant in `audio/sound.js`.

**Next on the list:** nothing planned. The open proposals below (death recap, stat overview, wave preview, gamepad,
vibration, pacts, daily challenge, boss medals, Cloudflare when the owner says go) wait for the owner's decision.

**Notes for the tests.** `npm run check` while developing (about 2 minutes, 5 when the sound engine changed),
`npm run release-check` before a release (about 35 to 45 minutes). Never run two browser tests at once (software WebGL
takes every core). Waits that depend on the game use `tests/lib/wait.mjs` (game time), never a fixed real-time limit.
A new mechanic belongs in a self-test of its version (`core/selftest.js`, World steps without rendering) and in the
attack shots (`tests/attack-shots.mjs`).

## Requested on 04.10.2026 (later the same day): next ideas of the owner

Planned with the owner on 04.10.2026 (the order and the designs are in the HANDOFF above; faster tests done in
3.10.0):

- **Replace the grenade**: "the current grenades just aren't useful, you gotta get so close until they actually fly
  into the enemies that you'll basically always have defeated them already". Make it another, cooler mechanic that
  fits the game (with model, sound, telegraph and tests, like everything else).
- **Landscape only**: "the game is way better at landscape", so on phones it should open in landscape and always stay
  that way; PC keeps working as it does. (The portrait layouts, the portrait button layout of the editor and the
  portrait tests would go.)
- **Faster tests**: the release checks take about 45 minutes; optimize the steps for this project.

## Requested on 05.10.2026: always landscape, and the sound of Osmos

- **Always landscape** (done in 3.18.0): "remove the turn phone thing and make the game simply always landscape, like
  Clash of Clans / Brawl Stars": the shell in `index.html` turns the game when the phone is held upright. Open: the
  behaviour of touches in the turned frame on a real iPhone (Safari) could not be tested without a device.
  **Reversed on 06.10.2026** (owner: "the always landscape thing is kinda weird, maybe just keep the turn phone thing"):
  3.28.1 removes the shell and brings back the rotate screen of 3.11.0 (held upright: "Turn your device", a run waits).
- **A more professional look** (owner, 05.10.2026: "it's all looking like a kids game, we need more professional
  style"). Looked at the current pictures first. What reads as toy-like: flat, evenly lit low-poly shapes without
  material (no metal or roughness, no wear, no ambient occlusion, soft blob shadows), saturated flat colours in the
  Cryo Vault and in the effects (the pink slab of a telegraph, white glowing blobs), the same rounded chunky shapes for
  props, enemies and the walker. The HUD and the cards are already restrained. To plan with the owner: a graded look
  (filmic tone mapping, a little bloom, vignette and grain, less saturation, one accent colour per biome), PBR-style
  materials with a few small details (panel lines, bolts, wear, emissive strips), contact shadows and AO, telegraphs as
  thin hazard outlines and hatching instead of flat slabs, calmer effect colours, a tighter model language (hard-surface
  shapes for machines, organic only for the Hive). Needs a decision: how far (a polish pass on everything vs. an opt-in
  Ultra preset), and a reference (a game or a picture whose look is meant).
  **Ultra was tried and removed (3.20.0 to 3.28.2).** Owner, 06.10.2026, on his phone: "ultra graphics just make my phone hot
  and fps low while looking kind of the same as high ... colors actually look worse most of the time". Checked with pictures:
  true. The tone curve plus the grade washed the colours out, the sun's shadow on the shadow catcher was barely visible, and the
  price was a second pass for the shadow map, a 4x multisampled half-float target at full resolution and a full-screen pass.
  Lessons: judge a look on the real device, not by pictures from a software renderer; a better look must come from the
  lights, colours and models of the normal setting (cheap, for everyone), not from extra passes. Still wanted, with a
  reference picture from the owner.
- **Sound direction** (the owner likes the mobile game _Osmos_): high quality stereo ambience, a nice subtle melody and
  ambient effect sounds, noticeable and pleasant, distinct for each biome. To plan (not built yet): wider stereo (slow
  auto-panned pads, ping-pong echoes, per-voice width), a soft evolving melody per biome in its own scale and timbre
  (glassy bells, felt piano, warm pads), long reverb tails; the current themes are the starting point.

### CURRENT STATE (06.10.2026, afternoon; read this first when the work goes on)

- **Live:** 3.28.1 (merged as #55 on 06.10.2026: the fixes of the checkup, the rotate screen back instead of the turning
  shell). Before that 3.28.0 with the whole stack #43 to #54; #44 to #53 were closed as contained in it.
- **Open (3.29.0, one PR against main that also contains 3.28.2 / #56):** richer colours and light for every graphics setting
  (the owner: "just improve the graphics generally ... which actually makes a difference"): a stronger sun, a coloured fill light
  from the other side, a richer floor where it was grey (Blackout City, Cryo Vault); judged from pictures only, to be seen on a
  phone. Contents of 3.28.2: the Ultra graphics setting is removed (see "A more professional look"); the controller is
  looked for once a second instead of every frame when none is connected; a cleanup (unused exports and imports, dead code,
  README, the Daily payout without the Shard Refinery) and fixes of the test tools (the Whiteout check, the layout audit behind
  the rotate screen, the soak verdict and its hang after a crash).
- **For the owner:** delete the merged `claude/*` branches on GitHub (this session may push but not delete branches);
  `claude/music-lab` has one commit that is not in main (a Music Lab of 03.10.2026): keep, merge or delete is his call.
- **Still open from before:** the second step of the sound direction (reference clips), the model pass for the
  professional look (a reference picture), the licence (`docs/GITHUB.md`), Cloudflare (when he says go; also needed for a
  Daily Rift leaderboard), the real-device tests (rotate screen on iPhone Safari and Android Chrome, a real gamepad, the
  vibration), and a 120-wave soak on a steadier machine (the test machine's browser crashed twice).

### HANDOFF (06.10.2026, after the night of autonomous work; history, superseded by CURRENT STATE above)

The owner slept and said: continue on your own until about 95 % of the limit, with the necessary and recommended things and
thorough checks in between. Never merge, never push to main. Everything below is built, tested and in open pull requests, STACKED:
each is based on the one before, so merge them in this order and, after each merge, switch the base of the next one to `main`
(GitHub shows the diff against its base):

| PR   | Version | What                                                                                                                                                                         |
| ---- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| #43  | 3.18.1  | the old track fades out when the music changes; the deep test no longer flips (seeded noise): this is also why the deploy of #41 was red                                     |
| #44  | 3.18.2  | the checkups as tools (soak, fuzz, balance) and a 24992 Hz tone removed                                                                                                      |
| #45  | 3.19.0  | the ambient bloom (stereo, a voice per biome, ping-pong echo): the Osmos direction, first step                                                                               |
| #46  | 3.20.0  | the Ultra look (tone curve, real shadows, grade pass): REMOVED again in 3.28.2, see the note under "A more professional look"                                                |
| #47  | 3.21.0  | the death recap ("What hit you"), docs/GITHUB.md                                                                                                                             |
| #48  | 3.22.0  | build stats in the pause menu, a look at the next wave                                                                                                                       |
| #49  | 3.23.0  | gamepad, vibration (determinism fixture updated for the new setting)                                                                                                         |
| #50  | 3.24.0  | boss medals                                                                                                                                                                  |
| #51  | 3.25.0  | Banish Protocol (workshop module; banish a card in the upgrade choice)                                                                                                       |
| #52  | 3.26.0  | Daily Rift (date seed, weapon and threat; best of the day, streak)                                                                                                           |
| #53  | 3.27.0  | Pacts (up to two optional risks for more shards)                                                                                                                             |
| #54  | 3.28.0  | Codex part Rift events (mutators, Overdrive attacks) (#54 carried the whole stack and was merged on 06.10.2026)                                                              |
| next | 3.28.1  | checkup fixes; the rotate screen is back instead of the turning shell (owner, 06.10.2026: "the always landscape thing is kinda weird, maybe just keep the turn phone thing") |

State of the tests: the complete release check ran on 3.18.1, 3.18.2, 3.19.0 (all ok), 3.20.0 (ok after one test fix), 3.23.0
(covers 3.21 to 3.23; ok after the determinism fixture update). 3.24.0 had `npm test` and its own sections.

Owner's decisions of 05.10.2026: the overlap of music is fixed by a fade (done); the sound goes on by synthesis first (he will send
reference clips: Osmos is the direction); the professional look was to be an opt-in Ultra preset (removed 3.28.2); tablets are landscape-only (since 3.28.1 by the rotate
screen again); the recommended order goes on; a repo description, topics and a licence are prepared (`docs/GITHUB.md`: the licence
needs his choice).

A4 (a short introduction to the Singularity and traps) turned out to exist already: a tip in wave 4 for the Singularity and one at the first trap warning
(`showTipOnce` in `main.js`). NOT done, still wanted: Cloudflare (when he says go), the second step of the sound direction (slow evolving
pads with auto-panning; reference clips), a pass on the models for the professional look (hard-surface shapes, bloom, ambient
occlusion; a reference picture), and the real-hardware tests (a gamepad, a phone: Safari and Chrome with the rotate screen, the
vibration).

Tools of the night: `npm run soak | fuzz | balance` (see README), `RL_NO_MINIFY=1 node build.js`, `SHOT_QUALITY=battery node tools/qa.js
biome-shots pc`, `node tools/qa.js scape-preview music` (stereo MP3s in tests/shots/scapes).

Known and not ours: the headless Chromium of the test machine crashes now and then in long runs (its GPU process logs errors; the
game's heap is flat), and GitHub Actions sometimes does not start a job for 15 minutes and cancels it (a re-run works).

## Vorgemerkt, vom Eigentümer gewünscht (Reihenfolge nach Empfehlung)

### 1. Boss-Belohnungen

Done in 3.15.0 (05.10.2026, decisions in the HANDOFF above): Lockdown Grid (Warden), Crucible Hammer (Crucible),
Shard Field (Frost Prism), Brood (Hive Queen), Event Collapse (Rift Core). The notes below are the original plan.

- Nach dem Besiegen **jedes Bosses** gibt es nur **besonders starke Upgrades** (Angebot nur aus hohen Seltenheiten).
- Jeder der fünf Bosse (Warden, Crucible, Frost Prism, Hive Queen, Rift Core) hat eine **Chance auf ein exklusives
  Upgrade**, das man nur von diesem einen Boss bekommen kann.
- Heute: `bossRarityWeights` und der Filter `rarity < 2` bei Boss-Angeboten in `rollUpgradeOffer` (`core/waves.js`),
  Karten in `data/upgrades.js`.
- Beim Bau klären: Wie stark ist der heutige Filter, wie hoch die Chance (Vorschlag 25–35 %, erhöht sich nach
  Fehlschlägen), Kennzeichnung der exklusiven Karte im Upgrade-Bildschirm (Boss-Siegel, eigener Rahmen und Sound),
  Codex-Eintrag, Verhalten im Endless (mehrfach?), Tests, keine Doppelung mit Evolutionen.
- Ideen für die fünf Exklusiven (je ein Bezug zur Mechanik des Bosses): Warden „Lockdown-Gitter" (eigene Laser-Falle für
  Gegner), Crucible „Schmelztiegel" (Brandspur), Frost Prism „Splitterfeld", Hive Queen „Brut" (Drohnen-Begleiter),
  Rift Core „Singularität" (Sog-Nova).

### 2. Läufer statt Drohne (3.6.0) und Umgebungssounds

- Die Drohne wird ein **laufender Roboter mit zwei Beinen** (entschieden: zwei, nicht vier); Beine animiert beim
  Laufen, Steuerung unverändert, Dash als Schub oder Sprung, auch in der Startbildschirm-Vorschau.
- **Schritt-Sounds je Untergrund**: nasser Asphalt (Platschen), Eis (Knirschen und Rutschen), Metallgitter, Schlamm,
  Void-Platten (gläsern), Pfützen, Säure, Nähe zu Lava oder Gullys; Landung nach dem Dash, Rutschen auf Eis, Servo-Laut.
- **Ambient je Biom**: zufällige, ortsgebundene Geräusche (Tropfen, Eis-Knacken, Funken, Tiere, ferner Verkehr),
  nach links und rechts gepannt. Insgesamt „viel mehr Sounds".
- Grundlage ist da: Panning und Raum der Effekte (3.2.0), Boden-Atmosphäre je Biom (`MUSIC_BEDS`), Untergrund je
  Biom bekannt (`arena.ice`, `acid`, `vents`, `portals`).

### 3. Cloudflare (Hosting und Bestenliste)

Entscheidungen des Eigentümers (alles auf Cloudflare, GitHub Pages danach abschalten):

- Hosting als **Cloudflare Worker mit Static Assets** (`dist`) plus **D1-Bestenliste**. Voreingestellte Adresse
  `workers.dev` (eigene Domain optional; **die Adresse ändert sich, `localStorage`-Spielstände gehen verloren**, der
  Eigentümer muss vorher den Spielstand exportieren).
- **Punktzahl** = `Welle × 100 + Boss-Kills × 500 + Kills`, mal Threat-Faktor (Threat I–V: ×1.1 … ×1.5). Das Spiel
  hatte bisher keinen Punktewert.
- **Eine Zeile pro Spieler (Bestwert)**; ein **Gerätetoken** ist an den Namen gebunden (Namen sind frei, kein Filter).
- `wrangler.toml` in `cloudflare/` (im Dashboard Root directory `cloudflare`, Build `cd .. && npm ci && npm run build`,
  `NODE_VERSION` 22, Assets `../dist`, `run_worker_first = ["/api/*"]`, SPA-Fallback, D1-Binding mit `id` als TODO,
  Migrationen), `cloudflare/README.md` mit den Schritten im Dashboard, eigenes `cloudflare/package.json`.
  **Die Git-Anbindung nicht selbst herstellen** (macht der Eigentümer im Dashboard).
- `sw.js` darf `/api/*` nicht cachen (Cache-first mit `ignoreSearch` würde eine veraltete Bestenliste liefern).
- `compatibility_date` und die Syntax von `run_worker_first` beim Bau gegen die aktuelle Cloudflare-Doku prüfen.
- Vorschau-URLs je PR (Workers Builds) sind der echte Gewinn für „früher veröffentlichen"; ob Vorschauen dieselbe
  D1 nutzen, klären (sonst Testeinträge in der echten Liste). Auto-Merge hat der Eigentümer vorerst abgelehnt
  („wir lassen es bei meinem manuellen Merge").
- Der Eigentümer sagt Bescheid, wenn es losgehen soll. Voraussichtlich Release 3.7.0 oder höher.

### 4. Aus dem Checkup

- Erledigt in 3.6.0: Dash-Untergrenze 0,8 s, eigener Cooldown je Klinge bei Orbital Blades, Saver-Modus ohne
  Kantenglättung (ab dem nächsten Start) und Overlay in einfacher Auflösung, kleinere und gedämpftere Säurepfützen,
  Upgrade-Bildschirm auf dem Handy (kein Loch über REROLL, Werte und Einheiten brechen nicht mehr um), Combo Surge mit
  eigenem Effekt und Sound.
- Offen: Crucible-Modell wirkte im Screenshot körnig (vielleicht nur Software-Rendering). Die Bildrate der Tests
  (Software-GL, 5–8 fps) sagt nichts über echte Geräte.
- 3.7.0: der Übergang ruhig → Boss beginnt mit tiefer Taiko, Blech und Chor, die den kurzen Schnitt (bis 0,14 s)
  überdecken; ein echter Übergang (Ausblenden über einen Takt) bleibt eine Idee.

## Vorschläge vom 03.10.2026 (nach 3.7.0, Eigentümer entscheidet)

Gewünscht: sinnvolle Verbesserungen (Komfort usw.), die Spieler gern hätten, ohne dass das Spiel leichter wird. Jeder
Punkt mit seiner Wirkung auf die Schwierigkeit.

**A. Lernen und Überblick (neutral: erklärt, was passiert, nimmt nichts ab)**

1. (Done in 3.21.0: "What hit you" on the end screen of a lost run.) Tod-Rückblick am Run-Ende: die letzten Treffer (wer, welcher Angriff, wie viel), der tödliche Treffer hervorgehoben,
   dazu Schaden je eigener Quelle (Waffe, Klingen, Granate, Surge, Fallen) und je Gegnertyp. Lernt man am meisten,
   wenn das Spiel schwer ist.
2. (Done in 3.22.0.) Werte-Übersicht im Pausenmenü: alle aktuellen Werte (Schaden, Feuerrate, Krit, Tempo, Dash, Hülle, Panzerung,
   Regeneration, Aufsammelradius, Granaten) mit Grund- und Bonuswert.
3. (Done in 3.22.0.) Vorschau auf die nächste Welle in der Upgrade-Wahl (Boss, Ereignis, Mutator, ab wann Fallen kommen): man wählt
   passend, statt blind.
4. Kurze Einführung für Granate und Fallen in den Wellen 1–6, Codex-Einträge für Mutatoren und Overdrive-Angriffe.

**B. Bedienung (neutral)** 5. (Done in 3.23.0, tested with a faked controller only.) Gamepad (Sticks, Schultertasten, Start für Pause; Menüs zuerst weiter mit Maus/Touch) und Tastenbelegung am PC. 6. (Done in 3.23.0.) Vibration am Handy bei Treffern, Dash und Boss-Schlägen (nur Android, abschaltbar). 7. Getrennte Regler für Musik, Effekte und Atmosphäre (die Atmosphären sind seit 3.7.0 ein eigener Teil).
Done in 3.9.0: the "Ambience" volume (atmospheres, event beds and the sounds of the place). 8. Kompakte Schadenszahlen (pro Gegner zusammengezählt) gegen das Gewimmel im Endless; Farbenblind-Paletten für
Gegnerschüsse und Warnungen (zusätzlich zu „Clear warnings").

**C. Herausforderung (macht es freiwillig schwerer, belohnt Können)** 9. Pakte vor dem Run: bis zu zwei Nachteile wählen (zum Beispiel halbe Hülle, schnellere Gegner, keine Nova, Nebel)
für mehr Shards und ein Abzeichen in der Run-Historie; Meilensteine für Siege mit Pakten. 10. Tägliche Herausforderung: fester Seed, feste Waffe und feste Mutatoren für alle; eigener Bestwert (später die
Cloudflare-Bestenliste). 11. (Done in 3.24.0.) Boss-Medaillen: ohne Treffer und auf Zeit, je Boss Bronze, Silber, Gold im Codex. 12. Training gegen bereits besiegte Bosse (keine Belohnung): üben, ohne den Run leichter zu machen.

**D. Mit Vorsicht (macht es etwas leichter, nur begrenzt)** 13. „Verbannen" in der Upgrade-Wahl: eine Karte für den Run aus dem Pool nehmen, höchstens ein- bis zweimal pro Run
über ein Werkstatt-Modul freigeschaltet.

Empfehlung zur Reihenfolge: 3.8.0 Boss-Belohnungen (wie geplant), dann ein Paket „Lernen und Überblick" (1–3, klein bis
mittel, hoher Nutzen), dann Herausforderung (9–11), dann der Läufer. Gamepad und Vibration passen zu jedem Release.
(03.10.2026: the checkup releases 3.7.1–3.9.0 above come first, so the boss rewards move to 3.10.0.)

## Offene Zweifel (nur der Eigentümer kann sie prüfen)

- Musik 3.7.0: ob der neue Boss-Stil (Cinematic Synth) gefällt oder ein anderer probiert werden soll (Alternativen:
  durchgehend Synthwave/Darksynth oder Drum & Bass); ob die Atmosphären jetzt angenehm leise sind und der Chor nach
  Chor klingt (Formant-Filter, nur gemessen).
- Button-Layout-Editor (3.6.0) auf echten Handys: Ziehen mit dem Daumen, Größe des Panels, fester Stick im Kampf.
- Klang der ruhigen Tracks (3.5.0): ob Rohre, Kalimba und Glas so schön klingen wie die Eisglocken.
- Blackout-Event (3.4.0) auf dunklen Handy-Displays zu finster?
- Overdrive-Angriffe der Bosse (3.3.0) mit Handy-Steuerung fair? Erster Endless-Boss (Welle 25, doppelte Hülle) zu hart
  (Test-Bot starb 4–9 Mal)?
- Rechenlast der zwei Faltungshalls auf schwachen Handys (3.7.0 hat dafür die Verzerrer- und Gitarrenketten entfernt).

## Weitere gute Ideen (ungeprüft, nach Gewinn für „skalierendes, schwerer werdendes Spiel mit schönem Look und Klang")

**Endless und Herausforderung**

- Mutatoren vertiefen (3.3.0 hat sechs): Gegner-Elite-Eigenschaften stapeln, Herausforderungswellen (z. B. nur
  Schwarmgegner, nur Fernkämpfer), Welle mit Zeitlimit, Abyss-Gegner jenseits von Welle 100, Gravitationsquellen.
- **Pakte und Relikte** (Vor- und Nachteil wählen, gelten für den Run), Gadget-Wahl vor dem Run, weitere Gadgets
  (Wächter-Geschütz, Abstoßer, Schildkuppel).
- **Tägliche Herausforderung** mit festem Seed und eigener Bestenliste (passt zur Cloudflare-D1); wöchentlicher Mutator.
- Boss-Variationen pro Run (zufälliger Overdrive-Zusatz), Mini-Bosse in Endless alle 25 Wellen.

**Look**

- Biom-Wetter und Tageszeit pro Besuch (Regen verstärkt sich, Nebel zieht auf), bewegliche Hintergrund-Elemente
  (Hubschrauber über der Stadt, Züge im Void).
- Boss-Tod-Zeitlupe mit Kamerafahrt, Biom-Übergänge (Portal-Effekt zwischen den Bioms), Gegner-Skins pro Elite-Eigenschaft.
- Zusammenfassung am Run-Ende mit Schaden je Quelle, Zeitleiste, gesammelten Upgrades und der Punktzahl (Cloudflare).

**Klang**

- Musik reagiert auf Zustand: tiefer Hüllen-Herzschlag und Dämpfung bei wenig Hülle, Aufhellen nach einer Welle ohne Treffer.
- Getrennte Regler für Musik, Effekte und Ambient in den Einstellungen; Vorschau-Knopf für Ambient je Biom.
  (The Ambience volume came in 3.9.0.)
- Boss-Phasen mit eigenem Musik-Abschnitt (statt nur Enrage-Schicht), Sprach-Schnipsel im Hubschrauber/Funk.

**Qualität und Zugang**

- Farbenblind-Modus für Warnungen, Haptik am Handy bei Treffer und Dash. (03.10.2026: no option to reduce flashes and
  no left-handed mode; the owner had both removed in 3.8.0.)
- Gamepad-Unterstützung, Tastenbelegung.
- Frühe Welle 1–5 als bessere Einführung (kurzes Tutorial für Granate und Fallen), Codex-Einträge für Mutatoren und
  Overdrive-Angriffe.
- Auto-Qualität anhand echter Bildrate (Saver-Modus automatisch auf schwachen Geräten).

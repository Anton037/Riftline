// DOM UI (GameUI): screens, HUD, dialogs, workshop, records and settings, plus DOM helpers and icons.

import { RL_RT, logError } from "../core/diagnostics.js";
import {
  enemyDefs,
  bossDefs,
  enemyOrder,
  bossByBiome,
  RL_ENEMY_TIPS,
  biomeVariants,
  eliteAffixes,
} from "../data/enemies.js";
import { biomeList, biomesById } from "../data/biomes.js";
import { store } from "../main.js";
import { clamp, GAME_VERSION, formatCount, rlAgo, formatTime } from "../core/util.js";
import { weaponOrder, weaponDefs } from "../data/weapons.js";
import { MEDAL_NAMES } from "../core/medals.js";
import { dailyKey, dailySpec, liveStreak } from "../core/daily.js";
import { weekKey, weeklySpec } from "../core/weekly.js";
import { PACTS, PACT_MAX, pactBonus } from "../data/pacts.js";
import { waveEvents } from "../core/waves.js";
import { milestones, workshopModules, rlRetired, threatLevels } from "../data/progression.js";
import { upgradeList, rarityNames, upgradesById } from "../data/upgrades.js";
import { computeStats, weaponRange, buildStatRows } from "../core/stats.js";
import { RL_INPUT } from "./input.js";
import { clearFocus, rumble } from "./gamepad.js";
import { hapticMode } from "./haptics.js";
import { WHATS_NEW } from "../data/whatsnew.js";
import { MUTATORS } from "../core/mutators.js";
import { markHomeViewDirty } from "../render/renderer.js";

const RL_TOUCH_CLICK_GUARD = { until: 0, x: 0, y: 0, key: "" };
function rlUiClickKey(el) {
  if (!el) return "";
  if (el.id) return "id:" + el.id;
  const data = el.dataset || {};
  return data.buy
    ? "buy:" + data.buy
    : data.claim
      ? "claim:" + data.claim
      : data.go
        ? "go:" + data.go
        : el.hasAttribute && el.hasAttribute("data-back")
          ? "back"
          : "";
}
function rlRenderHistory() {
  const el = document.getElementById("runHist");
  if (!el) return;
  const history = store.data.history || [];
  if (!history.length) {
    el.innerHTML = '<p class="note">No runs yet — your last 12 runs appear here.</p>';
    return;
  }
  const killerName = (id) =>
    id === "lava"
      ? "a lava vent"
      : id === "shock"
        ? "a live manhole"
        : id === "acid"
          ? "acid"
          : id === "trap"
            ? "a trap"
            : enemyDefs[id]
              ? "a " + enemyDefs[id].name
              : bossDefs[id]
                ? bossDefs[id].name
                : "";
  el.innerHTML = history
    .map((run) => {
      const icon = run.outcome === "win" ? "trophy" : run.outcome === "quit" ? "close" : "skull",
        killer = run.outcome === "dead" ? killerName(run.killer) : "";
      const meta = [
        threatLevels[run.threat].name,
        formatTime(run.time),
        formatCount(run.kills) + " kills",
        "+" + formatCount(run.shards) + " shards",
        killer && "by " + killer,
        run.outcome === "quit" && "abandoned",
      ]
        .filter(Boolean)
        .join(" · ");
      const build = run.build.map((id) => upgradesById[id].name).join(" · ");
      return `<div class="row panel hist ${run.outcome}"><div class="rico">${iconSvg(icon)}</div><div><b>${run.outcome === "win" ? "Rift sealed" : "Wave " + run.wave}${run.endless ? " · Endless" : ""} · ${escapeHtml((weaponDefs[run.weapon] || rlRetired(run.weapon)).name)}</b><small>${escapeHtml(meta)}</small>${build ? `<small class="hist-build">${escapeHtml(build)}</small>` : ""}</div><span class="chip">${rlAgo(run.t)}</span></div>`;
    })
    .join("");
}
function rlBiomeTitle(biome) {
  return biome.tag ? `${biome.name} \xB7 ${biome.tag}` : biome.name;
}
const iconPaths = {
  gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/><circle cx="12" cy="12" r="6.5"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  play: '<path d="M7 4.5l12 7.5-12 7.5z"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  shard: '<path d="M12 2.5l5 7-5 12-5-12z"/><path d="M7 9.5h10"/>',
  lock: '<rect x="5" y="10.5" width="14" height="10" rx="1.5"/><path d="M8 10.5V7.5a4 4 0 018 0v3"/>',
  dash: '<path d="M3 12h10M6 7h8M6 17h8"/><path d="M14 6l6 6-6 6"/>',
  star: '<path d="M12 2.5l2.6 6.2 6.7.5-5.1 4.4 1.6 6.5L12 16.6l-5.8 3.5 1.6-6.5-5.1-4.4 6.7-.5z"/>',
  burst:
    '<path d="M12 2.5v5M12 16.5v5M2.5 12h5M16.5 12h5M5.3 5.3l3.5 3.5M15.2 15.2l3.5 3.5M5.3 18.7l3.5-3.5M15.2 8.8l3.5-3.5"/><circle cx="12" cy="12" r="2"/>',
  rate: '<path d="M4 7l5 5-5 5M11 7l5 5-5 5M18 7v10"/>',
  shield: '<path d="M12 2.5l8 3v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10v-6z"/>',
  wing: '<path d="M3 16c4-1 7-4 9-10 1 5 4 8 9 9-4 2-10 3-18 1z"/>',
  arrow: '<path d="M3 12h16M14 6l6 6-6 6"/>',
  magnet: '<path d="M6 3v8a6 6 0 0012 0V3"/><path d="M6 7h4M14 7h4"/>',
  crosshair: '<circle cx="12" cy="12" r="7.5"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5"/>',
  heart: '<path d="M12 20s-8-4.8-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 9c0 6.2-8 11-8 11z"/>',
  fan: '<path d="M12 21V11M12 11L5 4M12 11l7-7M12 11V3"/>',
  pierce: '<path d="M2 12h20M17 7l5 5-5 5"/><circle cx="8" cy="12" r="3"/>',
  bounce: '<path d="M3 18l6-12 6 12 6-12"/>',
  orbit:
    '<circle cx="12" cy="12" r="2.5"/><ellipse cx="12" cy="12" rx="9.5" ry="4.5"/><circle cx="20.5" cy="10.5" r="1.3"/>',
  snow: '<path d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7"/><path d="M9 4l3 2 3-2M9 20l3-2 3 2"/>',
  bolt: '<path d="M13 2L5 13h6l-1 9 8-11h-6z"/>',
  flame: '<path d="M12 22c-4 0-7-3-7-7 0-4 3-6 4-10 2 2 3 4 3 6 1-1 2-2 2-4 3 3 5 5 5 8 0 4-3 7-7 7z"/>',
  // Field Supply's icon (it was added at start-up by main.js until 3.32.0)
  map: '<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z"/><path d="M9 4v14M15 6v14"/>',
  drone: '<rect x="8" y="9" width="8" height="6" rx="1.5"/><path d="M8 12H3M16 12h5M5 9v6M19 9v6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
  reroll: '<path d="M20 11a8 8 0 00-14.5-4.5M4 13a8 8 0 0014.5 4.5"/><path d="M5 3v4h4M19 21v-4h-4"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  trophy: '<path d="M7 4h10v5a5 5 0 01-10 0z"/><path d="M7 6H4a3 3 0 003 4M17 6h3a3 3 0 01-3 4M12 14v4M8 21h8"/>',
  wrench: '<path d="M14.5 5.5a4 4 0 00-5.2 5.2L3 17l4 4 6.3-6.3a4 4 0 005.2-5.2l-2.7 2.7-2.8-.5-.5-2.8z"/>',
  check: '<path d="M4 12.5l5 5 11-11"/>',
  save: '<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/>',
  load: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v4h16v-4"/>',
  calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  skull:
    '<path d="M12 3a8 8 0 00-5 14.2V21h10v-3.8A8 8 0 0012 3z"/><circle cx="9" cy="11" r="1.6"/><circle cx="15" cy="11" r="1.6"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  // 3.15.0: the boss cards (a laser cage, the hammer, a larva, an imploding ring)
  lockdown: '<path d="M5 4v16M19 4v16M5 8h14M5 16h14"/><path d="M12 8v8" stroke-dasharray="2 2"/>',
  hammer: '<path d="M4 6h10v5H4z"/><path d="M9 11v10M14 8.5h5"/><path d="M17 6v5"/>',
  brood:
    '<ellipse cx="12" cy="14" rx="4" ry="6"/><path d="M8 11l-5-3M16 11l5-3M8 15l-4 2M16 15l4 2M10 8l-1-4M14 8l1-4"/>',
  collapse:
    '<circle cx="12" cy="12" r="9" stroke-dasharray="3 2.5"/><path d="M12 5v4M12 15v4M5 12h4M15 12h4"/><circle cx="12" cy="12" r="1.6"/>',
  // 3.49.0: the Tyrant's Tithe (a shard rising off the ember)
  tribute: '<circle cx="12" cy="12" r="8.5"/><path d="M12 6.5l2.8 4L12 17.5l-2.8-7z"/>',
};
function iconSvg(name, cls = "") {
  let paths = iconPaths[name] || iconPaths.info;
  return `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
}
const getById = (id) => document.getElementById(id),
  menuScreens = ["home", "workshop", "records", "daily", "pacts", "news", "settings"],
  formatTenths = (value) => (Math.round(value * 10 + 1e-6) / 10).toString(),
  formatPercent = (value) => Math.round(value * 100) + "%",
  formatCooldown = (value) => (value > 0 ? formatTenths(value) + " s" : "off"),
  statRows = [
    ["Damage", (stats) => stats.weapon.dmg * stats.dmgMul, formatTenths],
    ["Fire rate", (stats) => stats.weapon.rate * stats.rateMul, (value) => formatTenths(value) + "/s"],
    ["Projectiles", (stats) => stats.weapon.count + (stats.weapon.cone ? stats.extra * 2 : stats.extra), String],
    ["Pierce", (stats) => (stats.pierce > 99 ? 0 : stats.pierce), String],
    ["Bounces", (stats) => stats.bounce, String],
    ["Crit", (stats) => stats.crit, formatPercent],
    ["Max HP", (stats) => stats.maxHp, String],
    ["Speed", (stats) => stats.speed, (value) => formatTenths(value) + " m/s"],
    ["Range", (stats) => stats.range, (value) => Math.round(value) + " m"],
    ["Pickup radius", (stats) => stats.magnet, (value) => formatTenths(value) + " m"],
    ["Dash cooldown", (stats) => stats.dashCd, formatCooldown],
    ["Aegis every", (stats) => stats.shieldCd, formatCooldown],
    ["Regen", (stats) => stats.regen, (value) => formatTenths(value) + " HP/s"],
    ["Blades", (stats) => stats.orbit, String],
    ["Blade damage", (stats) => (stats.orbit ? stats.orbitDmg * stats.dmgMul : 0), formatTenths],
    ["Slow chance", (stats) => stats.cryo, formatPercent],
    ["Chain chance", (stats) => stats.arc, formatPercent],
    ["Bolt jumps", (stats) => stats.chain, String],
    [
      "Flame burn",
      (stats) => (stats.burn ? stats.burn * stats.burnMul * stats.dmgMul : 0),
      (value) => formatTenths(value) + "/s",
    ],
    ["Chain jumps", (stats) => (stats.arc ? stats.arcJumps : 0), String],
    ["Blast", (stats) => stats.payloadF, formatPercent],
    ["Singularities", (stats) => stats.gadgetMax, String], // 3.0.0, 3.12.0: the Singularity
    ["Singularity recharge", (stats) => stats.gadgetCd, formatCooldown],
    ["Collapse damage", (stats) => stats.gadgetDmg, (value) => "\u00d7" + formatTenths(value)],
    ["Burn", (stats) => stats.thermite, formatPercent],
    ["Repair chance", (stats) => stats.siphonCh, formatPercent],
    ["Nova radius", (stats) => stats.novaR, (value) => formatTenths(value) + " m"],
    ["Drones", (stats) => stats.wingmen, String],
    ["Bloodrush cap", (stats) => (stats.bloodrush ? 0.4 : 0), formatPercent], // 2.6.0
  ],
  damageSources = {
    arc: ["Arc Relay", "#c58bff"],
    burn: ["Burning", "#ff8a2a"],
    payload: ["Payload", "#ffa13d"],
    orbit: ["Orbital Blades", "#9ff8ff"],
    wingman: ["Wingman", "#49f2ff"],
    dash: ["Shock Dash", "#7ff6ff"],
    trail: ["Phantom trail", "#7ff6ff"],
    nova: ["Nova", "#7ff6ff"],
    pop: ["Bomber blasts", "#ffe14a"],
    lava: ["Lava", "#ff6a2a"],
    inferno: ["Inferno", "#ff5a3a"],
    grenade: ["Singularity", "#b57bff"], // 3.12.0: the old id of the gadget, kept for saved run records
    trap: ["Arena traps", "#aeb9cf"], // 3.0.0: enemies caught by a trap
    // 3.15.0: the boss cards
    lockdown: ["Lockdown Grid", "#ff4a5a"],
    hammer: ["Crucible Hammer", "#ff8a2a"],
    shard: ["Shard Field", "#9ae6ff"],
    brood: ["Brood", "#a8f03a"],
    other: ["Other", "#93a2bf"],
  },
  escapeHtml = (text) =>
    String(text).replace(
      /[&<>"']/g,
      (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch],
    ),
  GameUI = class {
    constructor(game) {
      this.g = game;
      this.screen = "home";
      this.stack = [];
      this.viewWeapon = 0;
      this.viewThreat = 0;
      this.hudCache = {};
      // 3.46.0: the buff row and its step bars are cached per frame (see buffs)
      this.buffRow = null;
      this.buffBars = new Map();
      this.buffTimed = new Map();
      this.dlgResolve = null;
      this.fillIcons(document);
      getById("pauseBtn").innerHTML = iconSvg("pause");
      this.bind();
    }
    fillIcons(root) {
      for (let el of root.querySelectorAll("[data-icon]")) {
        if (!el.dataset.filled) {
          el.dataset.filled = "1";
          el.insertAdjacentHTML("afterbegin", iconSvg(el.dataset.icon));
        }
      }
    }
    get save() {
      return this.g.store.data;
    }
    click(el, action) {
      if (!el) return;
      let touchDown = 0,
        startX = 0,
        startY = 0,
        pointerId = 0,
        activate = () => {
          if (el.disabled || el.hidden) return false;
          this.g.sound.play("click");
          action();
          return true;
        };
      el.addEventListener(
        "pointerdown",
        (ev) => {
          // 3.31.0: a second finger may tap a button when no other touch is on it (pause while a thumb holds a stick;
          // browsers send no click for such a tap). A second finger on a button already pressed does not take it over.
          if ((ev.pointerType === "touch" || ev.pointerType === "pen") && (ev.isPrimary !== false || !touchDown)) {
            startX = ev.clientX;
            startY = ev.clientY;
            pointerId = ev.pointerId;
            touchDown = 1;
          }
        },
        { passive: false },
      );
      el.addEventListener(
        "pointerup",
        (ev) => {
          if (!(ev.pointerType === "touch" || ev.pointerType === "pen") || !touchDown || ev.pointerId !== pointerId)
            return;
          let dx = ev.clientX - startX,
            dy = ev.clientY - startY;
          touchDown = 0;
          if (Math.hypot(dx, dy) > 14 || !activate()) return;
          ev.preventDefault();
          ev.stopPropagation();
          const now = performance.now();
          RL_TOUCH_CLICK_GUARD.until = now + 800;
          RL_TOUCH_CLICK_GUARD.x = ev.clientX;
          RL_TOUCH_CLICK_GUARD.y = ev.clientY;
          RL_TOUCH_CLICK_GUARD.key = rlUiClickKey(el);
        },
        { passive: false },
      );
      el.addEventListener(
        "pointercancel",
        (ev) => {
          if (ev.pointerId === pointerId) {
            touchDown = 0;
          }
        },
        { passive: true },
      );
      el.addEventListener("click", (ev) => {
        const now = performance.now(),
          guard = RL_TOUCH_CLICK_GUARD,
          dx = Number(ev.clientX) - guard.x,
          dy = Number(ev.clientY) - guard.y,
          near = Number.isFinite(dx) && Number.isFinite(dy) && Math.hypot(dx, dy) <= 36,
          key = rlUiClickKey(el),
          same = !!(guard.key && key && guard.key === key) || near;
        if (now < guard.until && same) {
          guard.until = 0;
          guard.key = "";
          RL_RT.uiGuardDrops++;
          ev.preventDefault();
          ev.stopPropagation();
          return;
        }
        guard.until = 0;
        guard.key = "";
        activate();
      });
    }
    bind() {
      for (let el of document.querySelectorAll("[data-go]")) this.click(el, () => this.show(el.dataset.go));
      for (let el of document.querySelectorAll("[data-back]")) this.click(el, () => this.back());
      this.click(getById("wPrev"), () => this.stepWeapon(-1));
      this.click(getById("wNext"), () => this.stepWeapon(1));
      this.click(getById("tPrev"), () => this.stepThreat(-1));
      this.click(getById("tNext"), () => this.stepThreat(1));
      this.click(getById("wBuy"), () => this.buyWeapon());
      this.click(getById("playBtn"), () => this.play());
      this.click(getById("dailyStart"), () => this.playDaily());
      this.click(getById("weeklyStart"), () => this.playWeekly());
      this.click(getById("continueBtn"), () => this.g.startRun({ resume: true }));
      let onPress = (el, action) =>
        el.addEventListener("pointerdown", (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          action();
        });
      onPress(getById("dashBtn"), () => {
        this.g.input.press("dash");
        let world = this.g.world,
          btn = getById("dashBtn");
        if (world && world.player.dashCdT > 0.08) {
          btn.classList.remove("deny");
          btn.offsetWidth;
          btn.classList.add("deny");
          this.g.sound.play("deny");
        }
      });
      onPress(getById("novaBtn"), () => {
        this.g.input.press("nova");
        let world = this.g.world,
          btn = getById("novaBtn");
        if (world && world.player.nova < 100) {
          btn.classList.remove("deny");
          btn.offsetWidth;
          btn.classList.add("deny");
          this.g.sound.play("deny");
        }
      });
      onPress(getById("gadgetBtn"), () => {
        // the deny flash comes from the simulation's gadgetDeny event (no charge, or outside a fight)
        this.g.input.press("gadget");
      });
      this.click(getById("pauseBtn"), () => this.g.pause());
      this.click(getById("resumeBtn"), () => this.g.resume());
      this.click(getById("abandonBtn"), async () => {
        if (
          await this.confirm("Abandon run?", "You keep the shards collected so far, but the run ends here.", "Abandon")
        ) {
          this.g.abandon();
        }
      });
      this.click(getById("rerollBtn"), () => this.g.reroll());
      this.click(getById("restartBtn"), async () => {
        if (
          await this.confirm(
            "Restart run?",
            "Shards collected so far are kept. A fresh run starts with the same weapon and threat.",
            "Restart",
          )
        ) {
          this.g.restart();
        }
      });
      this.click(getById("retryBtn"), () => this.g.retry());
      this.click(getById("homeBtn"), () => this.g.goHome());
      this.click(getById("endlessBtn"), () => this.g.endless());
      this.click(getById("crashHome"), () => this.g.recover());
      this.click(getById("crashCopy"), () => this.copy(getById("crashLog").value));
      let settings = () => this.save.settings,
        bindToggle = (id, key) => {
          let input = getById(id);
          input.addEventListener("change", () => {
            settings()[key] = input.checked;
            this.g.settingsChanged();
          });
        };
      bindToggle("setAuto", "autoFire");
      bindToggle("setAssist", "assist");
      bindToggle("setVibration", "vibration");
      // 3.45.4: feel what the setting does, wherever this device can buzz at all
      this.click(getById("setVibTest"), () => {
        this.toast(rumble("slam", true) ? "Buzz sent" : "Nothing here to buzz with");
      });
      bindToggle("setNumbers", "numbers");
      for (let [id, key] of [
        ["setSfx", "sfx"],
        ["setMusic", "music"],
        ["setAmb", "ambience"],
      ]) {
        let input = getById(id);
        input.addEventListener("input", () => {
          settings()[key] = +input.value;
          this.g.settingsChanged(true);
          // 3.48.0: hear the bus you are turning, at the level you just set (a shot of the weapon in
          // hand for effects, the arrival braam of the place for music, one far voice for the ambience)
          this.g.sound.previewBus(key, this.save.weapon);
        });
        input.addEventListener("change", () => {
          this.g.settingsChanged();
        });
      }
      for (let btn of getById("setQuality").querySelectorAll("button"))
        this.click(btn, () => {
          settings().quality = btn.dataset.v;
          this.renderSettings();
          this.g.settingsChanged();
        });
      this.click(getById("resetBtn"), async () => {
        if (
          (await this.confirm(
            "Reset all progress?",
            "Shards, workshop, weapons, records and milestones are wiped. Settings stay.",
            "Continue",
          )) &&
          (await this.confirm("Really reset?", "This cannot be undone.", "Reset everything", true))
        ) {
          this.g.resetProgress();
        }
      });
      // 3.48.0: the stock settings come back in one tap (progress is not touched)
      this.click(getById("defaultsBtn"), async () => {
        if (
          await this.confirm(
            "Restore default settings?",
            "Audio, video, controls and the HUD layout go back to stock. Your progress stays as it is.",
            "Restore",
          )
        ) {
          this.g.resetSettings();
        }
      });
      getById("dialog").addEventListener("click", (ev) => {
        if (ev.target === getById("dialog")) {
          this.closeDialog(null);
        }
      });
    }
    show(screen) {
      if (menuScreens.includes(this.screen) && this.screen !== screen) {
        this.stack.push(this.screen);
      }
      this._show(screen);
    }
    _show(screen) {
      // 2.3.6: the renderer re-measures the free space of the home screen for the drone preview
      markHomeViewDirty();
      // 2.5.0 D: Records opened from another screen start on the stats
      if (screen === "records" && this.screen !== "records") {
        this.recTab = "stats";
      }
      for (let id of menuScreens) getById(id).hidden = id !== screen;
      // 3.28.1: the gamepad's ring of focus stays on the screen it was on
      clearFocus();
      this.screen = screen;
      if (screen === "home") {
        this.stack = [];
        this.renderHome();
      }
      if (screen === "workshop") {
        this.renderWorkshop();
      }
      if (screen === "records") {
        this.renderRecords();
      }
      if (screen === "daily") {
        this.renderDaily();
        this.renderWeekly();
      }
      if (screen === "pacts") {
        this.renderPacts();
      }
      if (screen === "news") {
        this.renderNews();
      }
      if (screen === "settings") {
        this.renderSettings();
      }
    }
    back() {
      // 2.4.2: from settings opened in the pause menu back to the pause menu
      if (this.rlFromPause) {
        closePauseSettings(this);
        getById("pause").hidden = false;
        this.screen = "pause";
        return;
      }
      this._show(this.stack.pop() || "home");
    }
    hideMenus() {
      for (let id of menuScreens) getById(id).hidden = true;
      this.screen = "game";
    }
    renderHome() {
      let save = this.save;
      getById("bank").textContent = formatCount(save.shards);
      for (let el of document.querySelectorAll(".bankMirror")) el.textContent = formatCount(save.shards);
      if (this.viewWeapon == null || !weaponOrder[this.viewWeapon]) {
        this.viewWeapon = 0;
      }
      if (!this.homeInit) {
        this.viewWeapon = weaponOrder.indexOf(save.weapon);
        this.viewThreat = save.threat;
        this.homeInit = true;
      }
      this.renderWeapon();
      this.renderThreat();
      let run = save.run,
        btn = getById("continueBtn");
      if (run) {
        btn.hidden = false;
        btn.innerHTML = `${iconSvg("play")}CONTINUE \xB7 WAVE ${run.wave + (run.offer ? 1 : 0)} \xB7 ${escapeHtml(weaponDefs[run.weapon].name)}`;
        getById("playBtn").classList.remove("primary");
      } else {
        btn.hidden = true;
        getById("playBtn").classList.add("primary");
      }
      this.updatePlayState();
      getById("recBadge").hidden = !this.g.claimable().length;
      getById("newsBadge").hidden = !!save.seen["news_" + GAME_VERSION];
      // 3.26.0: a dot on the Rifts page until today's Rift has been played (3.58.0: and this week's)
      getById("dailyBadge").hidden = save.stats.daily.key === dailyKey() && save.stats.weekly.key === weekKey();
      getById("pactsLabel").textContent = save.pacts.length ? `Pacts \xB7 ${save.pacts.length}` : "Pacts";
      let stats = save.stats;
      getById("bestLine").hidden = !stats.runs;
      if (stats.runs) {
        getById("bestLine").textContent =
          `Best wave ${stats.bestWave}` +
          (stats.clears ? ` \xB7 ${stats.clears} clear${stats.clears > 1 ? "s" : ""}` : "");
      }
    }
    renderWeapon() {
      let save = this.save,
        id = weaponOrder[this.viewWeapon],
        weapon = weaponDefs[id],
        owned = !!save.weapons[id],
        card = document.querySelector(".weapon-card");
      card.classList.toggle("locked", !owned);
      card.style.setProperty("--wc", "#" + weapon.color.toString(16).padStart(6, "0"));
      getById("wIndex").textContent = `${this.viewWeapon + 1}/${weaponOrder.length}`;
      getById("wName").innerHTML = (owned ? "" : iconSvg("lock", "inline")) + escapeHtml(weapon.name);
      if (getById("wName").querySelector(".ico")) {
        getById("wName").querySelector(".ico").style.cssText =
          "display:inline-block;vertical-align:-3px;margin-right:6px;width:18px;height:18px";
      }
      getById("wBlurb").textContent = weapon.blurb;
      let burst = weapon.dmg * weapon.count + (weapon.explodeDmg || 0),
        range = weaponRange(weapon),
        segs = (value) => {
          let lit = clamp(Math.round(value), 1, 8);
          return (
            '<div class="segs">' +
            Array.from({ length: 8 }, (_, i) => `<i class="${i < lit ? "on" : ""}"></i>`).join("") +
            "</div>"
          );
        },
        dmgText =
          weapon.count > 1
            ? `${weapon.dmg}\xD7${weapon.count}`
            : weapon.explodeDmg
              ? `${weapon.dmg}+${weapon.explodeDmg}`
              : String(weapon.dmg);
      getById("wStats").innerHTML = `
    <div class="stat"><span class="k">DAMAGE</span><span class="v">${dmgText}</span>${segs((burst / 55) * 8)}</div>
    <div class="stat"><span class="k">RATE</span><span class="v">${weapon.rate.toFixed(1)}/s</span>${segs((weapon.rate / 6.5) * 8)}</div>
    <div class="stat"><span class="k">RANGE</span><span class="v">${Math.round(range)} m</span>${segs((range / 28) * 8)}</div>`;
      let buyBtn = getById("wBuy");
      buyBtn.hidden = owned;
      if (!owned) {
        buyBtn.innerHTML = `UNLOCK \xB7 <span class="shard-ico"></span>${weapon.cost}`;
        buyBtn.disabled = save.shards < weapon.cost;
      }
      getById("wPrev").disabled = this.viewWeapon <= 0;
      getById("wNext").disabled = this.viewWeapon >= weaponOrder.length - 1;
      this.updatePlayState();
      this.g.previewWeapon(owned ? id : save.weapon);
    }
    renderThreat() {
      let save = this.save,
        threat = threatLevels[this.viewThreat],
        locked = this.viewThreat > save.threatMax;
      getById("tName").textContent = threat.name;
      getById("tName").classList.toggle("hot", this.viewThreat > 0);
      getById("tDesc").textContent = locked
        ? `Clear all ${20} waves on ${threatLevels[this.viewThreat - 1].name} to unlock`
        : this.viewThreat > 0
          ? `${threat.desc} Shards \xD7${(1 + 0.25 * this.viewThreat).toFixed(2)}`
          : threat.desc;
      getById("tPrev").disabled = this.viewThreat <= 0;
      getById("tNext").disabled = this.viewThreat >= Math.min(5, save.threatMax + 1);
      this.updatePlayState();
    }
    updatePlayState() {
      let save = this.save,
        id = weaponOrder[this.viewWeapon],
        playable = !!save.weapons[id] && this.viewThreat <= save.threatMax,
        btn = getById("playBtn");
      btn.disabled = !playable;
      btn.textContent = playable
        ? save.run
          ? "NEW RUN"
          : "START RUN"
        : save.weapons[id]
          ? "THREAT LOCKED"
          : "WEAPON LOCKED";
    }
    stepWeapon(dir) {
      this.viewWeapon = clamp(this.viewWeapon + dir, 0, weaponOrder.length - 1);
      let id = weaponOrder[this.viewWeapon];
      if (this.save.weapons[id]) {
        this.save.weapon = id;
        this.g.store.save("weapon");
      }
      this.renderWeapon();
    }
    stepThreat(dir) {
      this.viewThreat = clamp(this.viewThreat + dir, 0, Math.min(5, this.save.threatMax + 1));
      if (this.viewThreat <= this.save.threatMax) {
        this.save.threat = this.viewThreat;
        this.g.store.save("threat");
      }
      this.renderThreat();
    }
    buyWeapon() {
      let save = this.save,
        id = weaponOrder[this.viewWeapon],
        weapon = weaponDefs[id];
      if (save.weapons[id] || save.shards < weapon.cost) {
        this.g.sound.play("deny");
        return;
      }
      save.shards -= weapon.cost;
      save.weapons[id] = true;
      save.weapon = id;
      this.g.store.save("buy");
      this.g.sound.play("buy");
      this.toast(`${weapon.name} unlocked`, "gold");
      this.renderHome();
    }
    async play() {
      let save = this.save;
      if (
        !(
          save.run &&
          !(await this.confirm(
            "Start a new run?",
            `Your run at wave ${save.run.wave} ends here. You keep the shards collected in it.`,
            "New run",
          ))
        )
      ) {
        if (save.run) {
          this.g.discardRun();
        }
        this.g.startRun({});
      }
    }
    renderWorkshop() {
      let save = this.save;
      for (let el of document.querySelectorAll(".bankMirror")) el.textContent = formatCount(save.shards);
      let list = getById("wsList");
      list.innerHTML = workshopModules
        .map((mod) => {
          let level = save.workshop[mod.id] || 0,
            maxLevel = mod.costs.length,
            cost = mod.costs[level],
            pips = Array.from({ length: maxLevel }, (_, i) => `<i class="${i < level ? "on" : ""}"></i>`).join(""),
            btn =
              level >= maxLevel
                ? '<button class="btn" disabled>MAX</button>'
                : `<button class="btn" data-buy="${mod.id}" ${save.shards < cost ? "disabled" : ""}><span class="shard-ico"></span>${cost}</button>`;
          return `<div class="row panel"><div class="rico">${iconSvg(mod.icon)}</div><div><b>${escapeHtml(mod.name)}</b><small>${escapeHtml(mod.desc)}</small><div class="pips">${pips}</div></div>${btn}</div>`;
        })
        .join("");
      for (let btn of list.querySelectorAll("[data-buy]")) this.click(btn, () => this.buyModule(btn.dataset.buy));
    }
    buyModule(id) {
      let save = this.save,
        mod = workshopModules.find((mod) => mod.id === id),
        level = save.workshop[id] || 0,
        cost = mod.costs[level];
      if (cost == null || save.shards < cost) {
        this.g.sound.play("deny");
        return;
      }
      save.shards -= cost;
      save.workshop[id] = level + 1;
      this.g.store.save("workshop");
      this.g.sound.play("buy");
      this.renderWorkshop();
    }
    renderRecords() {
      let save = this.save,
        stats = save.stats;
      for (let el of document.querySelectorAll(".bankMirror")) el.textContent = formatCount(save.shards);
      let bossKills = Object.values(stats.bosses).reduce((sum, count) => sum + count, 0),
        cells = [
          ["Runs", stats.runs],
          ["Best wave", stats.bestWave || "\u2014"],
          ["Full clears", stats.clears],
          ["Enemies destroyed", formatCount(stats.kills)],
          ["Bosses defeated", bossKills],
          ["Best threat cleared", stats.bestClearThreat >= 0 ? threatLevels[stats.bestClearThreat].name : "\u2014"],
          ["Time in the rift", formatTime(stats.playTime)],
          ["Fastest clear", stats.bestTime > 0 ? formatTime(stats.bestTime) : "—"],
          ["Shards earned", formatCount(stats.shardsEarned)],
        ];
      getById("statGrid").innerHTML = cells
        .map(
          ([label, value]) =>
            `<div class="cell"><div class="k">${escapeHtml(label)}</div><div class="v">${escapeHtml(value)}</div></div>`,
        )
        .join("");
      let list = getById("msList");
      list.innerHTML = milestones
        .map((ms) => {
          let done = !!save.milestones[ms.id],
            ready = !done && ms.test(save),
            action = done
              ? `<span class="chip">${iconSvg("check")}DONE</span>`
              : ready
                ? `<button class="btn" data-claim="${ms.id}"><span class="shard-ico"></span>${ms.reward}</button>`
                : `<span class="chip"><span class="shard-ico"></span>${ms.reward}</span>`;
          return `<div class="row panel ${done ? "done" : ready ? "claim" : ""}"><div class="rico">${iconSvg(done ? "check" : "trophy")}</div><div><b>${escapeHtml(ms.name)}</b><small>${escapeHtml(ms.desc)}</small></div>${action}</div>`;
        })
        .join("");
      for (let btn of list.querySelectorAll("[data-claim]")) this.click(btn, () => this.claim(btn.dataset.claim));
      // 2.5.0 D: Stats / Codex tabs
      try {
        this.recordsTab(this.recTab || "stats");
      } catch (err) {
        console.warn("codex", err);
      }
      // recent runs list under the lifetime stats
      try {
        rlRenderHistory();
      } catch (err) {
        logError("history", err);
      }
    }
    claim(id) {
      let save = this.save,
        ms = milestones.find((milestone) => milestone.id === id);
      if (!(!ms || save.milestones[id] || !ms.test(save))) {
        save.milestones[id] = true;
        save.shards += ms.reward;
        this.g.store.save("claim");
        this.g.sound.play("buy");
        this.toast(`${ms.name}: +${ms.reward} shards`, "gold");
        this.renderRecords();
      }
    }
    // the What's new tab: opening it marks this version's notes as read (the badge on the home screen goes away)
    /* 3.27.0: the pacts page: each pact is a toggle, at most PACT_MAX at once; the choice is saved for the next runs */
    renderPacts() {
      const save = this.save,
        list = getById("pactList");
      for (let el of document.querySelectorAll(".bankMirror")) el.textContent = formatCount(save.shards);
      list.innerHTML = PACTS.map((pact) => {
        const on = save.pacts.includes(pact.id);
        return `<div class="row panel pact${on ? " on" : ""}"><div class="rico">${iconSvg(pact.icon)}</div><div><b>${escapeHtml(pact.name)}</b><small>${escapeHtml(pact.desc)} · shards +${Math.round(pact.shards * 100)}%</small></div><button class="btn${on ? " primary" : ""}" data-pact="${pact.id}" aria-pressed="${on}">${on ? "SIGNED" : "SIGN"}</button></div>`;
      }).join("");
      for (const btn of list.querySelectorAll("[data-pact]")) this.click(btn, () => this.togglePact(btn.dataset.pact));
      const bonus = Math.round(pactBonus(save.pacts) * 100);
      getById("pactSum").textContent = save.pacts.length
        ? `${save.pacts.length} of ${PACT_MAX} signed · shards +${bonus}% on every run`
        : `No pact signed (up to ${PACT_MAX}).`;
      getById("pactsLabel").textContent = save.pacts.length ? `Pacts \xB7 ${save.pacts.length}` : "Pacts";
    }
    togglePact(id) {
      const save = this.save;
      if (save.pacts.includes(id)) save.pacts = save.pacts.filter((x) => x !== id);
      else if (save.pacts.length >= PACT_MAX) {
        this.g.sound.play("deny");
        this.toast(`At most ${PACT_MAX} pacts: take one off first`, "hint");
        return;
      } else save.pacts = [...save.pacts, id];
      this.g.store.save("pacts");
      this.renderPacts();
    }
    /* 3.26.0: the Daily Rift page: today's weapon and threat, the best of the day, the streak */
    renderDaily() {
      const save = this.save,
        d = save.stats.daily,
        spec = dailySpec(),
        today = d.key === spec.key,
        weapon = weaponDefs[spec.weapon];
      for (let el of document.querySelectorAll(".bankMirror")) el.textContent = formatCount(save.shards);
      getById("dailyCard").innerHTML =
        `<div class="dc-day">${escapeHtml(spec.key)} · UTC</div>` +
        `<div class="dc-weapon">${escapeHtml(weapon.name)}</div>` +
        `<div class="dc-sub">${escapeHtml(threatLevels[spec.threat].name)} threat · no workshop modules · ${escapeHtml(weapon.blurb)}</div>`;
      getById("dailyStart").textContent = today ? "PLAY TODAY'S RIFT AGAIN" : "START TODAY'S RIFT";
      getById("dailyStats").innerHTML = [
        ["Today's best", today ? `Wave ${d.wave} · ${formatCount(d.kills)} kills` : "Not played yet"],
        ["Streak", `${liveStreak(d, spec.key)} day${liveStreak(d, spec.key) === 1 ? "" : "s"}`],
        ["Days played", d.days],
        ["Best wave ever", d.bestWave || "-"],
      ]
        .map(([label, value]) => `<div class="cell"><div class="k">${label}</div><div class="v">${value}</div></div>`)
        .join("");
    }
    async playDaily() {
      const save = this.save;
      if (
        save.run &&
        !(await this.confirm(
          "Start the Daily Rift?",
          `Your run at wave ${save.run.wave} ends here. You keep the shards collected in it.`,
          "Start",
        ))
      )
        return;
      if (save.run) this.g.discardRun();
      this.g.startRun({ daily: true });
    }
    /* 3.58.0: the Weekly Rift block: this week's weapon, threat and the two pinned mutators, the best of the week */
    renderWeekly() {
      const save = this.save,
        w = save.stats.weekly,
        spec = weeklySpec(),
        played = w.key === spec.key,
        weapon = weaponDefs[spec.weapon];
      getById("weeklyGlow").hidden = played;
      getById("weeklyCard").innerHTML =
        `<div class="dc-day">${escapeHtml(spec.key)} \xB7 UTC</div>` +
        `<div class="dc-weapon">${escapeHtml(weapon.name)}</div>` +
        `<div class="dc-sub">${escapeHtml(threatLevels[spec.threat].name)} threat \xB7 no workshop modules \xB7 ${escapeHtml(weapon.blurb)}</div>` +
        `<div class="dc-mods">${spec.mutators
          .map((id) => {
            const m = MUTATORS[id];
            return `<span class="dc-mod" style="color:${m.color}" title="${escapeHtml(m.desc)}">${escapeHtml(m.name)} <i>${escapeHtml(m.desc)}</i></span>`;
          })
          .join("")}</div>`;
      getById("weeklyStart").textContent = played ? "PLAY THIS WEEK'S RIFT AGAIN" : "START THIS WEEK'S RIFT";
      getById("weeklyStats").innerHTML = [
        ["This week's best", played ? `Wave ${w.wave} \xB7 ${formatCount(w.kills)} kills` : "Not played yet"],
        ["Weeks played", w.weeks],
        ["Best wave ever", w.bestWave || "-"],
      ]
        .map(([label, value]) => `<div class="cell"><div class="k">${label}</div><div class="v">${value}</div></div>`)
        .join("");
    }
    async playWeekly() {
      const save = this.save;
      if (
        save.run &&
        !(await this.confirm(
          "Start the Weekly Rift?",
          `Your run at wave ${save.run.wave} ends here. You keep the shards collected in it.`,
          "Start",
        ))
      )
        return;
      if (save.run) this.g.discardRun();
      this.g.startRun({ weekly: true });
    }
    renderNews() {
      getById("newsList").innerHTML = WHATS_NEW.map(
        (entry, i) =>
          `<h3 class="section-h">${escapeHtml(entry.version)} · ${escapeHtml(entry.title)}${i === 0 ? " · current" : ""}</h3>` +
          `<div class="set-group">${entry.items.map((t) => `<div class="set-row"><span>${escapeHtml(t)}</span></div>`).join("")}</div>`,
      ).join("");
      this.markSeen(["news_" + GAME_VERSION]);
    }
    renderSettings() {
      let settings = this.save.settings;
      getById("setAuto").checked = settings.autoFire;
      getById("setAssist").checked = settings.assist;
      getById("setVibration").checked = settings.vibration !== false;
      // 3.45.4: the note says what this device actually can do
      getById("vibNote").textContent =
        hapticMode() === "native"
          ? "Buzzes on this phone: hits, dashes, the end of a run."
          : hapticMode() === "tick"
            ? "iPhone: short ticks, on the iOS versions that still allow them."
            : "No vibration on this device. A connected controller still rumbles.";
      getById("setNumbers").checked = settings.numbers;
      getById("setSfx").value = settings.sfx;
      getById("setMusic").value = settings.music;
      getById("setAmb").value = settings.ambience;
      for (let btn of getById("setQuality").querySelectorAll("button"))
        btn.classList.toggle("on", btn.dataset.v === settings.quality);
      getById("qualityNote").textContent = this.g.qualityNote();
      getById("storageWarn").hidden = this.g.store.storageOk;
      getById("storageWarnText").textContent = this.g.store.held
        ? "the old save is kept unread (storage full): progress is not saved"
        : "storage is blocked in this browser";
      getById("verText").textContent = `v${GAME_VERSION}`;
      const ownLayout =
        !!settings.hudLayout || settings.stickFixed || settings.stickSize !== 1 || settings.hudAlpha !== 1;
      getById("hudLayoutNote").textContent = ownLayout
        ? "Your own layout is on."
        : "Move and resize the buttons and the sticks.";
    }
    async copy(text) {
      let ok = false;
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(text);
          ok = true;
        }
      } catch {}
      if (!ok) {
        let area = document.createElement("textarea");
        area.value = text;
        area.setAttribute("readonly", "");
        area.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
        document.body.appendChild(area);
        area.select();
        area.setSelectionRange(0, text.length);
        try {
          ok = document.execCommand("copy");
        } catch {
          ok = false;
        }
        area.remove();
      }
      this.toast(ok ? "Copied" : "Copy failed \u2014 select the text and copy it by hand");
      return ok;
    }
    dialog({ title, body, buttons, onOpen, read }) {
      // 3.28.1: the gamepad's ring of focus does not stay on the button that opened the dialog
      clearFocus();
      if (this.dlgResolve) {
        this.closeDialog(null);
      }
      getById("dlgTitle").textContent = title;
      getById("dlgBody").innerHTML = body;
      let row = getById("dlgBtns");
      row.innerHTML = "";
      return new Promise((resolve) => {
        this.dlgResolve = resolve;
        this.dlgRead = read || null;
        for (let spec of buttons) {
          let btn = document.createElement("button");
          btn.className = "btn " + (spec.cls || "");
          btn.textContent = spec.label;
          this.click(btn, () => this.closeDialog(spec.value));
          row.appendChild(btn);
        }
        getById("dialog").hidden = false;
        // 2.8.1: focus moves into the dialog and back to where it was on close. It lands on the main
        // button, or on the first (Cancel) one when the main action is destructive, so Enter is safe
        this.dlgFocusBack = document.activeElement;
        const main = row.querySelector(".primary") || row.firstElementChild;
        if (main) main.focus({ preventScroll: true });
        if (onOpen) {
          onOpen();
        }
      });
    }
    closeDialog(value) {
      let resolve = this.dlgResolve,
        text = this.dlgRead ? this.dlgRead() : undefined;
      this.dlgResolve = null;
      getById("dialog").hidden = true;
      const back = this.dlgFocusBack;
      this.dlgFocusBack = null;
      if (back && back.isConnected && typeof back.focus === "function") back.focus({ preventScroll: true });
      if (resolve) {
        resolve(this.dlgRead ? { value, text } : value);
      }
      this.dlgRead = null;
    }
    async confirm(title, text, okLabel, danger) {
      return (
        (await this.dialog({
          title,
          body: `<p>${escapeHtml(text)}</p>`,
          buttons: [
            { label: "Cancel", value: false, cls: "ghost" },
            { label: okLabel, value: true, cls: danger ? "danger" : "primary" },
          ],
        })) === true
      );
    }
    alert(title, text) {
      return this.dialog({
        title,
        body: `<p>${escapeHtml(text)}</p>`,
        buttons: [{ label: "OK", value: true, cls: "primary" }],
      });
    }
    toast(text, cls = "", ms = 2900) {
      let box = getById("toasts"),
        el = document.createElement("div");
      for (
        el.className = "toast " + cls,
          el.style.animationDuration = ms + "ms",
          el.textContent = text,
          box.appendChild(el);
        box.children.length > 3;
      )
        box.firstChild.remove();
      setTimeout(() => el.remove(), ms + 50);
    }
    banner(big, small, cls = "", ms = 2200) {
      let el = getById("banner");
      el.innerHTML = `<div class="bn ${cls}" style="animation-duration:${ms}ms"><div class="small">${escapeHtml(small || "")}</div><div class="big">${escapeHtml(big)}</div></div>`;
      clearTimeout(this.bannerT);
      this.bannerT = setTimeout(() => {
        el.innerHTML = "";
      }, ms + 50);
    }
    comboPop(combo, bonus) {
      // 3.45.0: one slot - a new milestone replaces the last pop instead of stacking
      if (this.comboPopEl) this.comboPopEl.remove();
      let el = document.createElement("div");
      el.className = "combo-pop";
      el.textContent = `\xD7${combo} COMBO  +${bonus}`;
      getById("hud").appendChild(el);
      this.comboPopEl = el;
      setTimeout(() => {
        if (this.comboPopEl === el) this.comboPopEl = null;
        el.remove();
      }, 1250);
    }
    coach(step, steps, text) {
      let box = getById("coach");
      if (step == null) {
        box.hidden = true;
        this.coachKey = null;
        return;
      }
      let key = step + text;
      if (this.coachKey !== key) {
        this.coachKey = key;
        getById("coachDots").innerHTML = Array.from(
          { length: steps },
          (_, i) => `<i class="${i <= step ? "on" : ""}"></i>`,
        ).join("");
        getById("coachText").textContent = text;
        box.hidden = false;
      }
    }
    showHud(on) {
      getById("hud").hidden = !on;
      getById("hud").style.visibility = "";
      getById("vignette").classList.remove("low");
      getById("touch").hidden = !on;
      if (!on) {
        getById("bossBar").hidden = true;
      }
      this.hudCache = {};
      // 2.5.0 D: the end of a run hides the title cards like the banner
      this.clearTitleCard();
    }
    hud(world) {
      let cache = this.hudCache,
        player = world.player,
        stats = world.stats,
        update = (key, value, apply) => {
          if (cache[key] !== value) {
            cache[key] = value;
            apply(value);
          }
        },
        hp = Math.max(0, Math.ceil(player.hp));
      update("hp", hp + "/" + stats.maxHp, (text) => {
        getById("hpNum").textContent = text;
      });
      let hpFrac = clamp(player.hp / stats.maxHp, 0, 1);
      // 3.45.0: one lag ghost was enough (the boss keeps its) - the hull is bar + number now
      update("hpf", Math.round(hpFrac * 100), () => {
        getById("hpFill").style.transform = `scaleX(${hpFrac})`;
        getById("hpFill").parentElement.classList.toggle("low", hpFrac < 0.3);
      });
      update("shieldOn", stats.shieldCd > 0, (on) => {
        getById("shieldPip").hidden = !on;
      });
      if (stats.shieldCd > 0) {
        update("shield", player.shield ? 100 : Math.round((player.shieldT / stats.shieldCd) * 20) * 5, (pct) => {
          getById("shieldPip").style.setProperty("--p", pct + "%");
          getById("shieldPip").classList.toggle("ready", pct >= 100);
        });
      }
      if (cache.hpVal != null && player.hp > cache.hpVal + 0.5) {
        let bar = getById("hpFill").parentElement;
        bar.classList.remove("heal");
        bar.offsetWidth;
        bar.classList.add("heal");
      }
      cache.hpVal = player.hp;
      this.buffs(world);
      update("low", player.alive && hpFrac < 0.25, (low) => {
        getById("vignette").classList.toggle("low", low);
      });
      // 3.41.0: the Whiteout draws its white edge over the view (CSS fades it with the fog ramp)
      update(
        "whiteout",
        !!(world.arena && world.event === "whiteout" && world.state === "fight" && world.arena.biome?.id === "vault"),
        (on) => {
          getById("vignette").classList.toggle("whiteout", on);
        },
      );
      update("shards", world.shards, (shards) => {
        getById("runShards").textContent = formatCount(shards);
        // 3.45.0: the bump re-reads the layout - at most twice a second; the number itself always moves
        let chip = getById("shardChip");
        if (cache.shardsSeen) {
          let now = performance.now();
          if (now - (cache.shardBump || 0) > 450) {
            cache.shardBump = now;
            chip.classList.remove("bump");
            chip.offsetWidth;
            chip.classList.add("bump");
          }
        }
        cache.shardsSeen = true;
      });
      let waveMax = world.endless ? "" : "/" + 20;
      update("wave", world.wave + waveMax, () => {
        getById("waveLabel").textContent = `WAVE ${world.wave}${waveMax}`;
      });
      // 3.45.0: the progress bar carries the wave's count ("N LEFT" churned text with every kill;
      // a boss fight is named by the boss bar, CLEARED stays for the moment between the waves)
      let sub = world.state === "cleared" ? "CLEARED" : "\xA0";
      update("sub", sub, (text) => {
        getById("waveSub").textContent = text;
      });
      let showProg = world.state === "fight" && !world.boss && !world.bossPending && world.planTotal > 0;
      update("progOn", showProg, (on) => {
        getById("waveProg").hidden = !on;
      });
      if (showProg) {
        let left = world.enemies.length + world.markers.length;
        for (let i = world.planIdx; i < world.plan.length; i++) left += world.plan[i].members.length;
        let progress = clamp(1 - left / Math.max(world.planTotal, left), 0, 1);
        update("prog", Math.round(progress * 50), () => {
          getById("waveProgFill").style.transform = `scaleX(${progress})`;
        });
      }
      let boss = world.boss || (world.champion && !world.champion.dead ? world.champion : null);
      update("bossOn", !!boss, (on) => {
        getById("bossBar").hidden = !on;
      });
      if (boss) {
        update("bossName", boss.type + (boss.enraged ? "!" : "") + (boss.champion ? "c" : ""), () => {
          getById("bossName").textContent = boss.champion
            ? `${enemyDefs[boss.type].name.toUpperCase()} CHAMPION`
            : bossDefs[boss.type].name;
          getById("bossPhase").textContent = boss.enraged ? "ENRAGED" : boss.champion ? "RALLYING" : "";
        });
        update("bossF", Math.round((boss.hp / boss.maxHp) * 100), (value) => {
          getById("bossFill").style.transform = `scaleX(${clamp(value / 100, 0, 1)})`;
          getById("bossLag").style.transform = `scaleX(${clamp(value / 100, 0, 1)})`;
        });
        update("bossTicks", boss.type, (type) => {
          getById("bossTicks").innerHTML = type === "core" ? '<s style="left:66%"></s><s style="left:33%"></s>' : "";
        });
      }
      let combo = world.combo >= 5 ? world.combo : 0;
      update("combo", combo, (combo) => {
        getById("combo").hidden = !combo;
        if (combo) {
          getById("comboN").textContent = "\xD7" + combo;
          getById("combo").classList.toggle("hot", combo >= 25);
        }
      });
      if (combo) {
        update("comboT", Math.round(world.comboT * 20), (value) => {
          getById("comboBar").style.transform = `scaleX(${clamp(value / 44, 0, 1)})`;
        });
      }
      let dashPct = stats.dashCd > 0 ? Math.round((player.dashCdT / stats.dashCd) * 20) * 5 : 0;
      // 3.45.0: the ring (and the dimmed tint) say the cooldown - the per-decisecond seconds text is gone
      update("dash", dashPct, (pct) => {
        let btn = getById("dashBtn");
        btn.style.setProperty("--q", 100 - pct + "%");
        let cooling = pct > 0;
        if (btn.classList.contains("cooling") && !cooling) {
          btn.classList.remove("pop");
          btn.offsetWidth;
          btn.classList.add("pop");
          if (world.state === "fight") {
            this.g.sound.play("ready");
          }
        }
        btn.classList.toggle("cooling", cooling);
      });
      let nova = Math.floor(player.nova / 5) * 5;
      update("nova", nova, (pct) => {
        getById("novaBtn").style.setProperty("--p", pct + "%");
        getById("novaBtn").classList.toggle("ready", pct >= 100);
      });
      // 3.0.0: gadget charges as pips, recharge ring from gadgetT/gadgetCd
      const gadgetN = player.gadgetN | 0,
        gadgetMax = stats.gadgetMax | 0;
      update("gadgetPips", gadgetN + "/" + gadgetMax, () => {
        const pips = getById("gadgetPips");
        while (pips.children.length < gadgetMax) {
          pips.appendChild(document.createElement("i"));
        }
        while (pips.children.length > gadgetMax) {
          pips.lastChild.remove();
        }
        for (let i = 0; i < pips.children.length; i++) {
          pips.children[i].classList.toggle("on", i < gadgetN);
        }
        const btn = getById("gadgetBtn");
        btn.classList.toggle("empty", gadgetN <= 0);
        btn.setAttribute("aria-label", `Throw Singularity, ${gadgetN} of ${gadgetMax} ready`);
      });
      const gadgetPct =
        gadgetN >= gadgetMax || !(stats.gadgetCd > 0)
          ? 100
          : Math.round(clamp(1 - player.gadgetT / stats.gadgetCd, 0, 1) * 20) * 5;
      update("gadgetRing", gadgetPct, (pct) => {
        let btn = getById("gadgetBtn");
        // 3.45.0: the pips say how many charges are ready - the ring only speaks while one recharges
        btn.querySelector(".ring").hidden = pct >= 100;
        btn.style.setProperty("--q", pct + "%");
      });
    }
    buffs(world) {
      let player = world.player,
        stats = world.stats,
        chips = [];
      if (stats.bloodrush && player.rushN > 0) {
        chips.push(["rush", `RUSH \xD7${player.rushN}`, "#ff5a7a", player.rushT / 4]);
      }
      if (world.chronoT > 0) {
        chips.push(["chrono", "SLOW-MO", "#8fe8ff", world.chronoT / 1.5]);
      }
      if ((world.ws.revive || 0) > 0 && !world.revived) {
        chips.push(["life", "2ND LIFE", "#6dff8a", -1]);
      }
      if (world.barrierT > 0) {
        chips.push(["barrier", "BARRIER", "#7fd8ff", world.barrierT / Math.max(1, stats.barrierT || 1)]);
      }
      if (world.attuned && world.state === "fight") {
        chips.push(["attune", "ATTUNED", "#ffb86b", -1]);
      }
      if (world.event && world.state === "fight") {
        chips.unshift(["event", waveEvents[world.event].name, world.event === "elite" ? "#ffc84a" : "#7ff6ff", -1]);
      }
      // 3.3.0: the Endless mutators in play (with their level)
      for (const [id, level] of Object.entries(world.mods || {}))
        if (MUTATORS[id])
          chips.push([
            "mut-" + id,
            MUTATORS[id].name.toUpperCase() + (level > 1 ? " " + "I".repeat(level) : ""),
            MUTATORS[id].color,
            -1,
          ]);
      if (player.onIce && world.state === "fight") {
        chips.push(["ice", "ICE", "#bff4ff", -1]);
      }
      if (player.inAcid && world.state === "fight") {
        chips.push(["acid", "ACID", "#b4ff3d", -1]);
      }
      if (player.slowT > 0) {
        // 3.7.1: an electric trap stuns (0.8 s), ice chills (1.6 s)
        if (player.slowKind === "shock") chips.push(["shock", "STUNNED", "#ffe98a", player.slowT / 0.8]);
        else chips.push(["chill", "CHILLED", "#aee8ff", player.slowT / 1.6]);
      }
      let key = chips.map((chip) => chip[0] + chip[1]).join("|"),
        // 3.46.0: the row element is cached (it is static in the page); the step bars are cached
        // with it and die with the row on a rebuild (the bars used to be re-queried every frame)
        buffRow = this.buffRow || (this.buffRow = getById("buffs")),
        rebuilt = this.hudCache.buffKey !== key;
      if (rebuilt) {
        this.hudCache.buffKey = key;
        this.buffBars = new Map();
        buffRow.innerHTML = chips
          .map(
            ([id, text, color, left]) =>
              `<span class="buff" data-b="${id}" style="--bc:${color}">${text}${left >= 0 ? "<i></i>" : ""}</span>`,
          )
          .join("");
      }
      // 3.45.0: the little timers tick in 5 % steps and only write the step when it changes
      for (let [id, , , left] of chips) {
        if (left < 0) continue;
        let step = Math.round(clamp(left, 0, 1) * 20);
        // 3.45.3: `cache` was hud()'s local alias - buffs() reached for a global that does not exist, and the
        // first timed chip (a dash with Slipstream, a stun, a barrier) threw "Can't find variable: cache"
        // for three consecutive frames and killed the loop. The store is this.hudCache, as buffKey above.
        if (!rebuilt && this.hudCache["buff" + id] === step) continue;
        this.hudCache["buff" + id] = step;
        let bar = this.buffBars.get(id);
        if (!bar) {
          bar = buffRow.querySelector(`[data-b="${id}"] i`);
          if (bar) this.buffBars.set(id, bar);
        }
        if (bar) {
          bar.style.transform = `scaleX(${step / 20})`;
        }
      }
      // 2.5.0 A: chips for the timed upgrades (Heat Sink, Slipstream) and active Cryo Skates.
      // They are added next to the chips above, which may rebuild the row at any frame.
      const on = world.state === "fight" && player.alive,
        want = [];
      if (on && stats.heatSink && player.heatT > 0) {
        want.push(["heat", "HEAT", "#ff8a3d", player.heatT / 3]);
      }
      if (on && stats.slip && player.slipT > 0) {
        want.push(["slip", "SLIPSTREAM", "#7ff6ff", player.slipT / 1.37]);
      }
      if (on && stats.skates && player.skating) {
        want.push(["skate", "SKATES", "#bff4ff", -1]);
      }
      const row = buffRow;
      if (!row) return;
      // 3.46.0: the timed chips are cached too; a cached element is only trusted while it is
      // still connected (a rebuild of the row above may have dropped it)
      const timed = this.buffTimed;
      const live = (id) => {
        let el = timed.get(id);
        if (el && !el.isConnected) {
          timed.delete(id);
          el = null;
        }
        return el || null;
      };
      for (const id of timedBuffChips) {
        if (!want.some((chip) => chip[0] === id)) {
          const el = live(id);
          if (el) el.remove();
          else row.querySelector(`[data-b="${id}"]`)?.remove();
        }
      }
      for (const [id, text, color, left] of want) {
        let el = live(id) || row.querySelector(`[data-b="${id}"]`),
          fresh = false;
        if (!el) {
          el = document.createElement("span");
          el.className = "buff";
          el.dataset.b = id;
          el.style.setProperty("--bc", color);
          el.innerHTML = escapeHtml(text) + (left >= 0 ? "<i></i>" : "");
          row.appendChild(el);
          fresh = true;
        }
        timed.set(id, el);
        const step = Math.round(clamp(left, 0, 1) * 20);
        if (fresh || this.hudCache["buff" + id] !== step) {
          this.hudCache["buff" + id] = step;
          const bar = el.querySelector("i");
          if (bar) {
            bar.style.transform = `scaleX(${step / 20})`;
          }
        }
      }
    }
    showChoose(world) {
      let bossReward = world.offerBoss;
      getById("chooseEyebrow").textContent = bossReward
        ? `${bossDefs[world.bossKills[world.bossKills.length - 1]] ? bossDefs[world.bossKills[world.bossKills.length - 1]].name : "BOSS"} DEFEATED`
        : `WAVE ${world.wave} CLEARED`;
      getById("chooseTitle").textContent = bossReward ? "Claim a rare reward" : "Choose an upgrade";
      let hpFrac = clamp(world.player.hp / world.stats.maxHp, 0, 1);
      getById("chooseHp").style.transform = `scaleX(${hpFrac})`;
      getById("chooseHpNum").textContent = `${Math.ceil(world.player.hp)}/${world.stats.maxHp}`;
      this.renderNextWave(world);
      this.renderCards(world);
      this.coverHud(true);
      getById("choose").hidden = false;
    }
    /* 3.22.0: what the next wave brings, as chips under the title: the biome (when it is a new one), the boss, the wave
       event, the mutator that joins in Endless, traps */
    renderNextWave(world) {
      const box = getById("nextWave");
      if (!box) return;
      const next = world.previewWave(world.wave + 1),
        chips = [[`Wave ${next.wave}`, ""]];
      if (next.newBiome) chips.push([`Entering ${biomesById[next.biome].name}`, "biome"]);
      if (next.boss) chips.push([`Boss \u00b7 ${bossDefs[next.boss] ? bossDefs[next.boss].name : next.boss}`, "boss"]);
      if (next.event && waveEvents[next.event]) chips.push([waveEvents[next.event].name, "event"]);
      if (next.mutator && MUTATORS[next.mutator])
        chips.push([`New mutator \u00b7 ${MUTATORS[next.mutator].name}`, "mut"]);
      if (next.traps) chips.push(["Traps on the floor", ""]);
      box.innerHTML = chips.map(([text, cls]) => `<span class="nw ${cls}">${escapeHtml(text)}</span>`).join("");
    }
    renderCards(world) {
      // 2.4.2: the reroll label survives a re-render (reroll), so drop its old key hint first
      getById("rerollBtn")
        .querySelectorAll(".card-key")
        .forEach((el) => el.remove());
      let cards = getById("cards");
      cards.innerHTML = world.offer
        .map((id, i) => {
          let up = upgradesById[id],
            level = world.up[id] || 0,
            // 3.15.0: a boss card carries the seal of its boss
            tag = up.boss
              ? `${bossDefs[up.boss] ? bossDefs[up.boss].name.toUpperCase() : "BOSS"} \xB7 BOSS CARD`
              : up.evo
                ? "EVOLUTION"
                : up.repeat
                  ? rarityNames[up.rarity].toUpperCase()
                  : level
                    ? `LV ${level} \u2192 ${level + 1}`
                    : `NEW \xB7 ${rarityNames[up.rarity].toUpperCase()}`,
            evo = this.evoHint(up, world),
            delta = this.statDelta(id, world);
          const seal = up.boss ? `<span class="seal" aria-hidden="true">${iconSvg("skull")}</span>` : "";
          return `<button class="card r${up.rarity}" data-pick="${id}" style="animation-delay:${i * 70}ms">${seal}<span class="cico">${iconSvg(up.icon)}</span><span><span class="ctop"><b>${escapeHtml(up.name)}</b><span class="lv">${tag}</span></span><p>${escapeHtml(up.desc(level))}</p>${delta}${evo}</span></button>`;
        })
        .join("");
      cards.classList.add("locked");
      clearTimeout(this.armT);
      this.armT = setTimeout(() => cards.classList.remove("locked"), 650);
      for (let card of cards.querySelectorAll("[data-pick]")) {
        card.addEventListener("click", () => {
          if (!cards.classList.contains("locked")) {
            // 3.25.0: with Banish armed the card is banished instead of taken
            if (this.banishMode) this.g.banish(card.dataset.pick);
            else this.g.choose(card.dataset.pick);
          }
        });
        // 2.7.0: a soft tick when the mouse moves over a card (touch has no hover)
        card.addEventListener("pointerenter", (ev) => {
          if (ev.pointerType === "mouse" && !cards.classList.contains("locked")) this.g.sound.play("hover");
        });
      }
      // 3.25.0: Banish Protocol: shown when the module is owned (or a banish is left in a resumed run)
      {
        const btn = getById("banishBtn"),
          has = (world.ws.banish || 0) > 0 || world.banishes > 0;
        btn.hidden = !has;
        if (world.banishes <= 0 || world.offer.length < 2) this.banishMode = false;
        btn.disabled = world.banishes <= 0 || world.offer.length < 2;
        btn.classList.toggle("on", !!this.banishMode);
        getById("banishTxt").textContent = `Banish (${world.banishes})`;
        cards.classList.toggle("banishing", !!this.banishMode);
      }
      getById("rerollTxt").textContent = `Reroll (${world.rerolls})`;
      getById("rerollBtn").disabled = world.rerolls <= 0;
      getById("buildStrip").innerHTML = this.buildHtml(world);
      // 2.5.0 D: every upgrade that is offered counts as seen (also after a reroll and in a resumed run)
      try {
        this.markSeen((world.offer || []).filter((id) => upgradesById[id]).map((id) => "up_" + id));
      } catch (err) {
        console.warn("codex", err);
      }
      // 2.4.2: keys 1–4 pick a card, R rerolls (keyboard players only)
      if (!RL_INPUT.touch) {
        getById("cards")
          .querySelectorAll("[data-pick]")
          .forEach((card, i) => {
            card.classList.add("has-key");
            card.insertAdjacentHTML("beforeend", `<kbd class="card-key" aria-hidden="true">${i + 1}</kbd>`);
          });
        getById("rerollTxt").insertAdjacentHTML("afterend", '<kbd class="card-key inline" aria-hidden="true">R</kbd>');
      }
    }
    statDelta(id, world) {
      let player = world.player,
        stats = world.stats;
      if (id === "heal") {
        let healed = Math.min(stats.maxHp, player.hp + stats.maxHp * 0.45);
        return `<small class="delta">Hull ${Math.ceil(player.hp)} \u2192 ${Math.ceil(healed)}</small>`;
      }
      let next = computeStats(world.weapon, { ...world.up, [id]: (world.up[id] || 0) + 1 }, world.ws),
        lines = [];
      for (let [label, get, format] of statRows) {
        let before = get(stats),
          after = get(next);
        if (Math.abs(before - after) < 1e-6) continue;
        // 3.6.0: a value, its unit and the arrow never break apart (a lone "s" or "0/1" on a line of its own)
        const keep = (value) => String(format(value)).replace(/ /g, "\u00a0");
        lines.push(`${label} ${keep(before)}\u00a0\u2192\u00a0${keep(after)}`);
        if (lines.length >= 2) break;
      }
      return lines.length ? `<small class="delta">${escapeHtml(lines.join(" \xB7 "))}</small>` : "";
    }
    evoHint(up, world) {
      if (up.evo)
        return `<small class="evo-hint">Merges ${Object.keys(up.evo)
          .map((id) => escapeHtml(upgradesById[id].name))
          .join(" + ")}</small>`;
      let evos = upgradeList.filter(
          (evo) => evo.evo && evo.evo[up.id] && !world.up[evo.id] && (!evo.weapon || evo.weapon === world.weapon),
        ),
        evo = evos.find((evo) => evo.weapon) || evos[0];
      if (!evo) return "";
      let others = Object.keys(evo.evo)
          .filter((id) => id !== up.id)
          .map((id) => `${upgradesById[id].name}\u00a0${Math.min(world.up[id] || 0, evo.evo[id])}/${evo.evo[id]}`),
        mine = `${Math.min((world.up[up.id] || 0) + 1, evo.evo[up.id])}/${evo.evo[up.id]}`;
      return `<small class="evo-hint">\u2192 ${escapeHtml(evo.name)}: this\u00a0${mine} \xB7 ${escapeHtml(others.join(", "))}</small>`;
    }
    hideChoose() {
      getById("choose").hidden = true;
      this.coverHud(false);
    }
    coverHud(on) {
      getById("hud").style.visibility = on ? "hidden" : "";
      if (on) {
        getById("banner").innerHTML = "";
        clearTimeout(this.bannerT);
      }
      // 2.5.0 D: the upgrade choice and the pause menu hide the title cards like the banner
      if (on) {
        this.clearTitleCard();
      }
    }
    buildHtml(world) {
      let own = upgradeList.filter((upgrade) => world.up[upgrade.id] && !upgrade.repeat);
      return own.length
        ? own
            .map(
              (upgrade) =>
                `<span class="bi r${upgrade.rarity}" title="${escapeHtml(upgrade.name)}">${iconSvg(upgrade.icon)}${escapeHtml(upgrade.name)}${world.up[upgrade.id] > 1 ? " \xD7" + world.up[upgrade.id] : ""}</span>`,
            )
            .join("")
        : '<span class="note">No upgrades yet.</span>';
    }
    showPause(world) {
      getById("pauseTitle").textContent = `Wave ${world.wave}${world.endless ? " \xB7 Endless" : ""}`;
      getById("pauseStats").innerHTML =
        `<span>${formatTime(world.time)}</span><span>${formatCount(world.kills)} KILLS</span><span>${formatCount(world.shards)} SHARDS</span>`;
      getById("pauseBuild").innerHTML = this.buildHtml(world);
      this.renderStatRows(world);
      this.coverHud(true);
      getById("pause").hidden = false;
      this.screen = "pause";
      // 2.4.2: the build in the pause menu explains each upgrade on tap or click
      const own = upgradeList.filter((upgrade) => world.up[upgrade.id] && !upgrade.repeat),
        info = getById("pauseUpInfo");
      if (own.length) {
        getById("pauseBuild").innerHTML = own
          .map(
            (upgrade) =>
              `<button type="button" class="bi r${upgrade.rarity}" data-up="${upgrade.id}" aria-label="${escapeHtml(upgrade.name)}">${iconSvg(upgrade.icon)}${escapeHtml(upgrade.name)}${world.up[upgrade.id] > 1 ? " \xD7" + world.up[upgrade.id] : ""}</button>`,
          )
          .join("");
      }
      info.hidden = !own.length;
      info.innerHTML = '<p class="note">Select an upgrade to see what it does.</p>';
    }
    /* 3.22.0: the numbers behind the build: the value now and, next to it, how far it is from what the weapon has without the
       upgrades of the run (green: better, red: worse) */
    renderStatRows(world) {
      const box = getById("pauseStatRows");
      if (!box) return;
      const rows = buildStatRows(world.weapon, world.up || {}, world.ws || {}, world.player.hp),
        num = (v, digits) => (Math.round(v * 10 ** digits) / 10 ** digits).toFixed(digits).replace(/\.0+$/, "");
      box.innerHTML = rows
        .map((r) => {
          const value = r.hp != null ? `${Math.ceil(r.hp)} / ${num(r.now, r.digits)}` : num(r.now, r.digits) + r.unit,
            change = r.base ? (r.now - r.base) / r.base : 0;
          let delta = "",
            cls = "";
          if (Math.abs(change) >= 0.005) {
            const better = r.better === "up" ? change > 0 : change < 0;
            delta = `${change > 0 ? "+" : "\u2212"}${Math.round(Math.abs(change) * 100)}%`;
            cls = better ? "up" : "worse";
          }
          return `<span class="sr-k">${escapeHtml(r.label)}</span><span class="sr-v num">${escapeHtml(value)}</span><span class="sr-d ${cls}">${delta}</span>`;
        })
        .join("");
    }
    hidePause() {
      // 2.4.2: also closes settings opened from the pause menu
      closePauseSettings(this);
      getById("pause").hidden = true;
      getById("settings").hidden = true;
      this.coverHud(false);
    }
    // 2.4.2: settings from the pause menu (without backup and reset)
    openPauseSettings() {
      if (!this.g.paused || getById("pause").hidden) return;
      this.rlFromPause = true;
      getById("pause").hidden = true;
      getById("settings").classList.add("in-run");
      this._show("settings");
    }
    showOver(result) {
      getById("overEyebrow").textContent = result.win
        ? `${threatLevels[result.threat].name.toUpperCase()} \xB7 ALL ${20} WAVES`
        : `${weaponDefs[result.weapon].name.toUpperCase()} \xB7 ${threatLevels[result.threat].name.toUpperCase()}`;
      let title = getById("overTitle");
      title.textContent = result.win ? "RIFT SEALED" : result.abandoned ? "RUN ENDED" : "SIGNAL LOST";
      title.className = "over-title " + (result.win ? "win" : "lose");
      getById("overBest").hidden = !(result.best || result.fastest);
      getById("overBest").textContent = result.fastest && !result.best ? "NEW FASTEST" : "NEW BEST";
      let killer = result.killer ? enemyDefs[result.killer] || bossDefs[result.killer] : null;
      getById("overCause").hidden = !killer && !["lava", "shock", "acid", "trap"].includes(result.killer);
      if (killer) {
        getById("overCause").textContent = `Destroyed by ${bossDefs[result.killer] ? killer.name : "a " + killer.name}`;
      } else {
        if (result.killer === "lava") {
          getById("overCause").textContent = "Burned by a lava vent";
        } else if (result.killer === "shock") {
          getById("overCause").textContent = "Fried by a live manhole";
        } else {
          if (result.killer === "acid") {
            getById("overCause").textContent = "Dissolved in acid";
          } else if (result.killer === "trap") {
            getById("overCause").textContent = "Crushed by a trap";
          }
        }
      }
      // 3.26.0: a Daily Rift run says so, and what the day's best is (3.58.0: the Weekly Rift the same for its week)
      const over = getById("overDaily");
      over.hidden = !result.daily && !result.weekly;
      if (result.daily) {
        const ds = result.dailyStats;
        over.textContent = ds
          ? `Daily Rift ${result.daily} \xB7 best today wave ${ds.wave}${result.dailyBest ? " (new)" : ""} \xB7 streak ${ds.streak}`
          : `Daily Rift ${result.daily} \xB7 not counted (ended before wave 2)`;
      } else if (result.weekly) {
        const ws = result.weeklyStats;
        over.textContent = ws
          ? `Weekly Rift ${result.weekly} \xB7 best this week wave ${ws.wave}${result.weeklyBest ? " (new)" : ""}`
          : `Weekly Rift ${result.weekly} \xB7 not counted (ended before wave 2)`;
      }
      this.renderRecap(result);
      getById("overStats").innerHTML = [
        ["Wave", result.wave],
        ["Time", formatTime(result.time)],
        ["Kills", result.kills],
        ["Bosses", result.bosses],
      ]
        .map(([label, value]) => `<div class="cell"><div class="k">${label}</div><div class="v">${value}</div></div>`)
        .join("");
      getById("payRows").innerHTML = result.rows
        .map(
          ([label, value]) =>
            `<div class="pay-row"><span>${escapeHtml(label)}</span><span class="num">${escapeHtml(value)}</span></div>`,
        )
        .join("");
      getById("overMs").innerHTML =
        (result.medals || [])
          .map(
            (m) =>
              `<span class="chip">${iconSvg("trophy")} ${escapeHtml(MEDAL_NAMES[m.medal] || "Medal")} medal \u00b7 ${escapeHtml(m.name)} \u00b7 ${m.secs} s (par ${m.par} s)</span>`,
          )
          .join("") +
        (result.unlocks || [])
          .map((text) => `<span class="chip">${iconSvg("star")} ${escapeHtml(text)}</span>`)
          .join("") +
        result.milestones
          .map((text) => `<span class="chip">${iconSvg("trophy")} Milestone ready: ${escapeHtml(text)}</span>`)
          .join("");
      this.renderDamage(result);
      getById("endlessBtn").hidden = !result.canEndless;
      getById("retryBtn").hidden = result.canEndless;
      // 3.45.4: R runs again from the end screen (keyboard players only)
      if (!RL_INPUT.touch && !result.canEndless) {
        const retry = getById("retryBtn");
        if (!retry.querySelector(".card-key"))
          retry.insertAdjacentHTML("beforeend", '<kbd class="card-key inline">R</kbd>');
      }
      getById("over").hidden = false;
      this.countUp(getById("payTotal"), result.total);
      this.renderRunExtra();
    }
    // 1.6.0: run metrics for the game-over screen (game._runExtra, set in game.endRun)
    renderRunExtra() {
      const box = getById("overExtra"),
        extra = this.g && this.g._runExtra;
      if (!box) return;
      if (!extra) {
        box.hidden = true;
        return;
      }
      box.hidden = false;
      // 3.39.0: the damage totals live in the panels above (Damage dealt as bars, damage taken in the recap
      // of a lost run), so the grid keeps only what nothing else says
      box.innerHTML =
        '<div class="dh">Run performance</div><div class="run-extra-grid">' +
        [
          ["Crits", formatCount(extra.critHits || 0)],
          ["Dashes", formatCount(extra.dashes || 0)],
          ["Best combo", "×" + formatCount(extra.bestCombo || 0)],
        ]
          .map(
            ([label, value]) =>
              `<div class="xcell"><div class="xk">${escapeHtml(label)}</div><div class="xv num">${escapeHtml(value)}</div></div>`,
          )
          .join("") +
        "</div>";
    }
    /* 3.21.0: the recap of a lost run: who hit the drone last, with what and how long before the end, and where most of the
       damage of the run came from */
    renderRecap(result) {
      const box = getById("overRecap"),
        hits = (result.lastHits || []).slice(-6);
      box.hidden = !hits.length;
      if (box.hidden) return;
      const name = (src) =>
          (enemyDefs[src] && enemyDefs[src].name) ||
          (bossDefs[src] && bossDefs[src].name) ||
          { lava: "Lava vent", shock: "Live manhole", acid: "Acid", trap: "A trap" }[src] ||
          "Unknown",
        ago = (s) => (s < 0.15 ? "the end" : `${s.toFixed(1)} s before`);
      const taken = Object.entries(result.taken || {})
          .filter(([, dmg]) => dmg >= 1)
          .sort((a, b) => b[1] - a[1]),
        total = taken.reduce((sum, [, dmg]) => sum + dmg, 0);
      box.innerHTML =
        '<div class="dh">What hit you</div><div class="hits">' +
        hits
          .map((h, i) => {
            const final = i === hits.length - 1,
              ticks = h.n > 1 ? ` \xD7${h.n}` : "";
            return `<div class="hit${final ? " final" : ""}"><span class="hd">\u2212${formatCount(Math.round(h.dmg))}</span><span>${escapeHtml(name(h.src))}${ticks}${final ? " \u2014 final blow" : ""}</span><span class="hw">${ago(h.ago)}</span></div>`;
          })
          .join("") +
        "</div>" +
        (taken.length && total >= 20
          ? `<div class="rt">Most damage taken from: ${taken
              .slice(0, 3)
              .map(([src, dmg]) => `${escapeHtml(name(src))} (${Math.round((dmg / total) * 100)}%)`)
              .join(", ")}</div>`
          : "");
    }
    renderDamage(result) {
      let box = getById("overDmg"),
        bySource = result.dmgSrc || {},
        sources = Object.entries(bySource)
          .filter(([, dmg]) => dmg >= 1)
          .sort((a, b) => b[1] - a[1]),
        total = sources.reduce((sum, [, dmg]) => sum + dmg, 0);
      box.hidden = !sources.length || total < 50;
      if (box.hidden) return;
      let shown = sources.slice(0, 4),
        rest = sources.slice(4).reduce((sum, [, dmg]) => sum + dmg, 0);
      if (rest > 0) {
        shown.push(["other", rest]);
      }
      let top = shown[0][1];
      box.innerHTML =
        '<div class="dh">Damage dealt</div>' +
        shown
          .map(([src, dmg]) => {
            let label = src === "weapon" ? result.weaponName : damageSources[src] ? damageSources[src][0] : "Other",
              color =
                src === "weapon"
                  ? "#" + weaponDefs[result.weapon].color.toString(16).padStart(6, "0")
                  : damageSources[src]
                    ? damageSources[src][1]
                    : "#93a2bf",
              pct = Math.round((dmg / total) * 100);
            return `<div class="dmg-row" style="--dc:${color}"><span>${escapeHtml(label)}</span><span class="num">${formatCount(dmg)} \xB7 ${pct}%</span><span class="db"><i style="transform:scaleX(${(dmg / top).toFixed(3)})"></i></span></div>`;
          })
          .join("");
    }
    hideOver() {
      getById("over").hidden = true;
    }
    countUp(el, total) {
      let start = performance.now(),
        duration = 900,
        step = (now) => {
          let k = clamp((now - start) / duration, 0, 1);
          el.textContent = formatCount(Math.round(total * (1 - Math.pow(1 - k, 3))));
          if (k < 1) {
            requestAnimationFrame(step);
          }
        };
      requestAnimationFrame(step);
    }
    showCrash(log) {
      for (let id of ["choose", "pause", "over"]) getById(id).hidden = true;
      this.showHud(false);
      getById("crashLog").value = log;
      getById("crash").hidden = false;
    }
    hideCrash() {
      getById("crash").hidden = true;
    }
    // 3.0.0: the GADGET button reacts to the simulation: "ready" pops it, "deny" shakes it
    gadgetFlash(kind) {
      const btn = getById("gadgetBtn");
      btn.classList.remove(kind);
      btn.offsetWidth;
      btn.classList.add(kind);
    }
    hurtFlash() {
      let el = getById("flash");
      el.classList.add("on");
      requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove("on")));
    }
    // ---- 2.5.0 D: title cards (see the note above RL_BIOME_CARD)
    clearTitleCard() {
      this.titleCardN = (this.titleCardN || 0) + 1;
      this.cardHold = null;
      clearTimeout(this.titleCardT);
      const el = getById("titleCard");
      if (el) {
        el.innerHTML = "";
      }
    }
    // biome title card; it replaces the wave banner of its wave
    biomeCard(biome, wave, ms = 9000) {
      const info = rlBiomeCardInfo(biome);
      holdTitleCard(
        this,
        "biome",
        `<div class="tcard biome hold" data-biome="${escapeHtml(info.id)}" style="--bc:${info.color}"><div class="tc-band"><div class="tc-eye">${wave ? `Wave ${escapeHtml(wave)} \xB7 ` : ""}Entering</div><div class="tc-name">${escapeHtml(info.name)}</div>${info.hazard ? `<div class="tc-haz">${escapeHtml(info.hazard)}</div>` : ""}${info.boss ? `<div class="tc-boss"><span>Boss</span>${escapeHtml(info.boss)}</div>` : ""}</div></div>`,
        2500,
        ms,
      );
      return info;
    }
    // boss intro card, shown during the camera pan to a new boss
    bossCard(id, biome, ms = 9000) {
      const boss = bossDefs[id];
      if (!boss) return null;
      holdTitleCard(
        this,
        "boss",
        `<div class="tcard boss hold" data-boss="${escapeHtml(id)}" style="--bc:${rlHex(boss.color)}"><div class="tc-panel"><i class="tc-accent"></i><div class="tc-eye">Boss${biome ? " \xB7 " + escapeHtml(biome.name) : ""}</div><div class="tc-name">${escapeHtml(boss.name)}</div><i class="tc-line"></i><div class="tc-title">${escapeHtml(boss.title)}</div></div></div>`,
        2800,
        ms,
      );
      return boss;
    }
    // fades the held card out in 0.5 s, after it has been on screen for its minimum time
    releaseTitleCard() {
      const hold = this.cardHold;
      if (!hold) return;
      this.cardHold = null;
      if (this.titleCardN !== hold.token) return; // another card replaced it
      clearTimeout(this.titleCardT);
      this.titleCardT = setTimeout(
        () => {
          if (this.titleCardN !== hold.token) return;
          const card = document.querySelector("#titleCard .tcard");
          if (card) {
            card.classList.add("out");
          }
          this.titleCardT = setTimeout(
            () => this.titleCardN === hold.token && (getById("titleCard").innerHTML = ""),
            520,
          );
        },
        Math.max(0, hold.min - (performance.now() - hold.at)),
      );
    }
    // ---- 2.5.0 D: Codex "seen" keys; saves only when something is new
    markSeen(keys) {
      const seen = this.save && this.save.seen;
      if (!seen) return 0;
      let added = 0;
      for (const key of keys) {
        if (seen[key] !== true) {
          seen[key] = true;
          added++;
        }
      }
      if (added) {
        this.g.store.save("codex");
      }
      return added;
    }
    // ---- 2.5.0 D: Records: Stats / Codex tabs (built on first use, the page markup stays as it was)
    recordsTab(tab) {
      ensureRecordTabs(this);
      this.recTab = tab === "codex" ? "codex" : "stats";
      for (const btn of getById("recTabs").querySelectorAll("[data-rtab]")) {
        const on = btn.dataset.rtab === this.recTab;
        btn.classList.toggle("on", on);
        btn.setAttribute("aria-selected", on ? "true" : "false");
      }
      getById("records").querySelector(".scroll").hidden = this.recTab !== "stats";
      getById("codexList").hidden = this.recTab !== "codex";
      if (this.recTab === "codex") {
        this.renderCodex();
      }
    }
    renderCodex() {
      const codex = rlCodexEntries(this.save),
        all = [...codex.enemies, ...codex.bosses, ...codex.variants, ...codex.events],
        found = all.filter((entry) => entry.seen).length,
        rows = (list, hint) =>
          list
            .map((entry) => {
              const cls = `row panel cx${entry.seen ? "" : " unseen"}${entry.rarity ? " r" + entry.rarity : ""}`;
              if (!entry.seen)
                return `<div class="${cls}" data-cx="${escapeHtml(entry.key)}"><div class="rico">${iconSvg("lock")}</div><div><b>???</b><small>${escapeHtml(hint)}</small></div></div>`;
              return `<div class="${cls}" data-cx="${escapeHtml(entry.key)}"${entry.color ? ` style="--cc:${entry.color}"` : ""}><div class="rico">${iconSvg(entry.icon)}</div><div><b>${escapeHtml(entry.name)}</b><small>${escapeHtml(entry.desc)}</small>${entry.extra ? `<small class="cx-extra">${escapeHtml(entry.extra)}</small>` : ""}</div>${entry.tag ? `<span class="chip">${escapeHtml(entry.tag)}</span>` : ""}</div>`;
            })
            .join(""),
        part = (title, list, hint) =>
          `<h3 class="section-h">${title} <span class="cx-count">${list.filter((entry) => entry.seen).length}/${list.length}</span></h3><div class="codex-grid">${rows(list, hint)}</div>`;
      getById("codexList").innerHTML =
        `<p class="page-intro cx-intro"><b class="num">${found}/${all.length}</b> discovered. Enemies, bosses, variants and elites unlock when you meet them, events, mutators and Overdrive attacks when you see them.</p>` +
        part("Enemies", codex.enemies, "Not encountered yet") +
        part("Bosses", codex.bosses, "Not encountered yet") +
        part("Variants and elites", codex.variants, "Not encountered yet") +
        part("Rift events", codex.events, "Not seen yet");
    }
  };
// 2.5.0 A: HUD chips of the timed upgrades, managed next to the chips of GameUI.buffs
const timedBuffChips = ["heat", "slip", "skate"];
// 2.4.2: closes settings that were opened from the pause menu
function closePauseSettings(ui) {
  ui.rlFromPause = false;
  getById("settings").hidden = true;
  getById("settings").classList.remove("in-run");
}

/* ==========================================================================
 2.5.0 D: design — biome title card, boss intro card, Codex in Records
 - a new biome (wave 1 and every biome change) gets a full-width title card instead of the plain
   wave banner: biome name, its hazard in a few words and the boss that waits at its end
 - while the camera pans to a new boss (game.intro), a bigger name card shows the boss name and
   title with a short accent in the boss colour
 - Records get a second tab, the Codex: enemies, bosses and upgrades. Seen entries show their name
   and a short description, unseen ones "???". "Seen" lives in store.data.seen: enemy_<type> (set
   by the first-encounter tips), boss_<id> (set when a boss spawns) and up_<id> (set when an
   upgrade is offered). Old saves without these keys fall back to what the save already proves:
   defeated bosses (stats.bosses) and upgrades in recent builds or the saved run.
 Both cards take no input (pointer-events: none). They hold while the game needs them (first 1.6 s
 of the wave, the boss camera pan; see main.js) and then fade out.
 ========================================================================== */
// the hazard of each biome in a few words (the RL_BIOME_INFO tag is the fallback for new biomes)
const RL_BIOME_CARD = {
  yard: "Live manholes arc — lure enemies onto them",
  vault: "Slick ice under the aurora — the blizzard breathes, so does your drift",
  marsh: "The mud clings, the glowing tide eats your hull — and marks enemies",
  void: "Portal pairs fold the arena — shots pass through",
  club: "Magma vents jet molten rock — the ground itself burns",
  flats: "Dust devils wander the glass — they shove, and the wind bites",
};
// Codex texts for enemies without a first-encounter tip. Mites only come out of splitters (no
// spawn event, no tip), so they are known together with the Splitter.
const RL_CODEX_EXTRA = {
  mite: "Mites burst out of destroyed Splitters. Small and fast, but one shot each.",
};
const RL_CODEX_WITH = { mite: "splitter" };
const rlHex = (color) => "#" + ((Number(color) >>> 0) & 0xffffff).toString(16).padStart(6, "0");
function rlBiomeCardInfo(biome) {
  biome = biome || biomeList[0];
  const bossId = bossByBiome[biome.id],
    boss = bossId && bossDefs[bossId];
  return {
    id: biome.id,
    name: biome.name,
    hazard: RL_BIOME_CARD[biome.id] || biome.tag || "",
    boss: boss ? boss.name : "",
    color: rlHex(biome.grid != null ? biome.grid : 0x49f2ff),
  };
}
// Codex entries of a save. Names and texts come from the data tables at run time, so added or
// removed enemies, bosses and events show up without changes here. 3.39.0: no upgrade entries any
// more (the gallery is gone); a save that proves offered cards (history, saved run) needs no fallback.
function rlCodexEntries(save) {
  const data = save || {},
    seen = data.seen || {},
    beaten = (data.stats && data.stats.bosses) || {},
    medals = (data.stats && data.stats.medals) || {};
  const enemyIds = [
      ...enemyOrder.filter((id) => enemyDefs[id]),
      ...Object.keys(enemyDefs).filter((id) => !enemyOrder.includes(id)),
    ],
    bossBiome = Object.fromEntries(Object.entries(bossByBiome).map(([biomeId, id]) => [id, biomesById[biomeId]])),
    // the usual route: Blackout City first, the Shattered Core last
    rank = (id) => (id === "warden" ? 0 : id === "core" ? 9 : 1),
    bossIds = [
      ...new Set([
        ...biomeList.map((biome) => bossByBiome[biome.id]).filter((id) => bossDefs[id]),
        ...Object.keys(bossDefs),
      ]),
    ].sort((idA, idB) => rank(idA) - rank(idB));
  const enemies = enemyIds.map((id) => ({
      key: "enemy_" + id,
      id,
      seen: seen["enemy_" + id] === true || (!!RL_CODEX_WITH[id] && seen["enemy_" + RL_CODEX_WITH[id]] === true),
      name: enemyDefs[id].name,
      desc: RL_ENEMY_TIPS[id] || RL_CODEX_EXTRA[id] || "A creature of the rift.",
      color: rlHex(enemyDefs[id].color),
      icon: "skull",
    })),
    bosses = bossIds.map((id) => {
      const boss = bossDefs[id],
        kills = +beaten[id] || 0,
        bio = bossBiome[id];
      return {
        key: "boss_" + id,
        id,
        seen: seen["boss_" + id] === true || kills > 0,
        name: boss.name,
        desc: boss.title + (bio ? ` \xB7 ${bio.name}` : ""),
        extra:
          kills > 0
            ? `Defeated \xD7${kills}` +
              (medals[id] ? ` \xB7 ${MEDAL_NAMES[medals[id].medal]} \xB7 ${Math.round(medals[id].secs)} s` : "")
            : "",
        color: rlHex(boss.color),
        icon: "target",
      };
    });
  // 3.39.0: the Upgrades gallery is gone (the owner's clean-game pass): the cards' names, texts and rarity
  // frames are in every upgrade offer already, and the gallery was a static catalog of them. The seen
  // marking of offered cards ("up_<id>") stays, so saves keep working.
  // 3.28.0: the Endless mutators and the boss Overdrive attacks: found when one joins a run / a boss uses it for the first time
  const events = [
    ...Object.entries(MUTATORS).map(([id, m]) => ({
      key: "mut_" + id,
      id,
      seen: seen["mut_" + id] === true,
      name: "Mutator \xB7 " + m.name,
      desc: m.desc + ". From wave 21, one more every tenth wave; later they grow stronger.",
      color: m.color.replace("#", ""),
      icon: "burst",
    })),
    ...Object.entries(RL_OVERDRIVE_INFO).map(([boss, od]) => ({
      key: "od_" + boss,
      id: boss,
      seen: seen["od_" + boss] === true,
      name: "Overdrive \xB7 " + od.name,
      desc: od.desc,
      extra: (bossDefs[boss] ? bossDefs[boss].name : boss) + " when enraged",
      color: bossDefs[boss] ? rlHex(bossDefs[boss].color) : "",
      icon: "target",
    })),
  ];
  // 3.34.0: the wave events (Elite Surge, Shard Rain and the five biome events) join them
  for (const [id, ev] of Object.entries(waveEvents)) {
    const biome = ev.biome && biomesById[ev.biome];
    events.push({
      key: "ev_" + id,
      id,
      seen: seen["ev_" + id] === true,
      name: "Wave event \xB7 " + ev.name.charAt(0) + ev.name.slice(1).toLowerCase(),
      desc: ev.desc,
      extra: biome ? "Once a visit, in " + biome.name : "Any biome",
      color: biome ? rlHex(biome.accent) : "",
      icon: "bolt",
    });
  }
  // 3.34.0: the biome variants and the elite affixes (only a tint and a ring until now, never explained)
  const variants = [
    ...biomeList
      .filter((biome) => biomeVariants[biome.id])
      .map((biome) => {
        const v = biomeVariants[biome.id];
        return {
          key: "var_" + v.id,
          id: v.id,
          seen: seen["var_" + v.id] === true,
          name: v.name,
          desc: v.desc,
          extra: biome.name + " \xB7 " + v.types.map((t) => (enemyDefs[t] ? enemyDefs[t].name : t)).join(", "),
          color: rlHex(v.color),
          icon: "skull",
        };
      }),
    ...Object.entries(eliteAffixes).map(([id, a]) => ({
      key: "aff_" + id,
      id,
      seen: seen["aff_" + id] === true,
      name: a.name + " elite",
      desc: a.desc,
      color: rlHex(a.color),
      icon: "shield",
    })),
  ];
  return { enemies, bosses, variants, events };
}
// 3.28.0: the Overdrive attack of each boss (core/ai.js OVERDRIVE), as the Codex tells it
const RL_OVERDRIVE_INFO = {
  warden: {
    name: "Lockdown",
    desc: "A grid of lasers across the whole arena, then a second grid shifted by half a cell: step into a new cell before it closes.",
  },
  forge: {
    name: "Meltdown",
    desc: "Three rings of lava burst outwards from the Crucible, each with a gap of its own: find the gap.",
  },
  prism: {
    name: "Whiteout",
    desc: "Three frost beams turn around the Prism while ice shards hunt you in between.",
  },
  queen: {
    name: "Plague",
    desc: "The bloom wells up in a ring around you, two eggs hatch, then a dense spiral of spores.",
  },
  core: {
    name: "Collapse",
    desc: "Bombardments under and around you while a cross of six beams turns.",
  },
  kingpin: {
    name: "Firestorm",
    desc: "The burning dead pour in through ember portals, molotovs close a ring around you (one gap), and the Ash Tyrant sweeps the floor.",
  },
  wyrm: {
    name: "Noon",
    desc: "The sun stands still: a dial of five hot lances turns around the Glasswyrm while the glass bursts in two gapped rings.",
  },
};
// ---- 2.5.0 D: title card helpers
function titleCardLayer() {
  let el = getById("titleCard");
  if (!el) {
    el = document.createElement("div");
    el.id = "titleCard";
    el.setAttribute("aria-live", "polite");
    const banner = getById("banner");
    if (banner) {
      banner.after(el);
    } else {
      getById("app").appendChild(el);
    }
  }
  return el;
}
// The card starts after the next frame is on screen: the first frame of a new arena or boss can
// take long on slow devices (shader compiles), and the card must not run out during that stall.
function showTitleCard(ui, html, ms) {
  const el = titleCardLayer(),
    token = (ui.titleCardN = (ui.titleCardN || 0) + 1);
  clearTimeout(ui.titleCardT);
  el.innerHTML = "";
  requestAnimationFrame(() =>
    requestAnimationFrame(() => {
      if (ui.titleCardN !== token) return;
      el.innerHTML = html;
      ui.titleCardT = setTimeout(() => ui.titleCardN === token && (el.innerHTML = ""), ms + 60);
    }),
  );
  return token;
}
// Both cards hold until the game releases them (releaseTitleCard), because they follow game time:
// the biome card the first 1.6 s of its wave, the boss card the camera pan. Game time runs slower
// than the clock on a slow device and stalls while a new arena or boss is first drawn, so a card
// on a clock timer could be gone before the player saw it. `ms` is only a safety limit.
function holdTitleCard(ui, kind, html, min, ms) {
  getById("banner").innerHTML = "";
  clearTimeout(ui.bannerT);
  ui.cardHold = { token: showTitleCard(ui, html, ms), kind, at: performance.now(), min };
}
// ---- 2.5.0 D: the Stats / Codex tabs of Records, built on first use
function ensureRecordTabs(ui) {
  if (getById("recTabs")) return;
  const rec = getById("records"),
    main = rec.querySelector(".scroll");
  if (!main.id) {
    main.id = "recStats";
  }
  rec
    .querySelector(".topbar")
    .insertAdjacentHTML(
      "afterend",
      '<div id="recTabs" class="seg rec-tabs" role="tablist"><button type="button" role="tab" data-rtab="stats" class="on" aria-selected="true">Stats</button><button type="button" role="tab" data-rtab="codex" aria-selected="false">Codex</button></div>',
    );
  main.insertAdjacentHTML("afterend", '<div id="codexList" class="scroll codex" hidden></div>');
  for (const btn of getById("recTabs").querySelectorAll("[data-rtab]"))
    ui.click(btn, () => ui.recordsTab(btn.dataset.rtab));
}

export { GameUI, RL_TOUCH_CLICK_GUARD, getById, rlBiomeTitle, iconPaths, escapeHtml, rlBiomeCardInfo, rlCodexEntries };
